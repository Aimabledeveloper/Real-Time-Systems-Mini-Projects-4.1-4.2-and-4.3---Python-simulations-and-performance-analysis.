
"""
Mini Project 4.2
Multi-Rate Environmental Monitoring Pipeline

Defines independent environmental sensor streams and their
synthetic signals and processing-time models.
"""

from dataclasses import dataclass, field
import math
import random
from typing import List, Tuple


@dataclass
class SensorStream:
    """Represents one independent periodic sensor."""

    name: str
    period: float
    threshold: float
    base_value: float
    amplitude: float
    frequency: float
    phase: float = 0.0

    # Scheduling information
    next_due: float = 0.0
    last_sample_time: float = None

    # Sample history
    sample_times: List[float] = field(default_factory=list)
    sample_values: List[float] = field(default_factory=list)
    sample_status: List[str] = field(default_factory=list)

    # Timing-compliance counters
    required_samples: int = 0
    on_time_samples: int = 0
    late_samples: int = 0
    missed_samples: int = 0
    period_overruns: List[float] = field(default_factory=list)

    # Alert information
    alerts: List[dict] = field(default_factory=list)
    previous_value: float = None

    def signal_value(self, time_value: float) -> float:
        """
        Generate a smooth periodic environmental signal.

        The signal is deterministic for a given time.
        """

        return (
            self.base_value
            + self.amplitude
            * math.sin(
                2.0 * math.pi * self.frequency * time_value
                + self.phase
            )
        )

    def true_crossing_times(
        self,
        start_time: float,
        end_time: float
    ) -> List[float]:
        """
        Find upward threshold crossings in the underlying signal.

        This calculates actual signal crossings independently of
        sensor sampling, allowing alert latency to be measured.
        """

        crossings = []

        if self.amplitude <= 0:
            return crossings

        normalized = (
            (self.threshold - self.base_value) / self.amplitude
        )

        if normalized < -1.0 or normalized >= 1.0:
            return crossings

        angle = math.asin(normalized)

        # Upward crossing occurs where the sine wave is increasing.
        base_angle = angle

        period_of_signal = 1.0 / self.frequency

        first_cycle = math.floor(
            (
                2.0 * math.pi * self.frequency * start_time
                + self.phase
                - base_angle
            ) / (2.0 * math.pi)
        )

        last_cycle = math.ceil(
            (
                2.0 * math.pi * self.frequency * end_time
                + self.phase
                - base_angle
            ) / (2.0 * math.pi)
        )

        for cycle in range(first_cycle, last_cycle + 1):

            crossing = (
                base_angle
                + 2.0 * math.pi * cycle
                - self.phase
            ) / (2.0 * math.pi * self.frequency)

            if start_time < crossing <= end_time:
                crossings.append(crossing)

        return sorted(crossings)

    def processing_time(self, rng: random.Random) -> float:
        """
        Generate sensor processing time.

        Most readings are processed quickly. A small percentage
        experience a long-tail processing delay.
        """

        if rng.random() < 0.10:
            # Occasional long processing delay.
            return rng.uniform(0.12, 0.30)

        # Normal processing time.
        return rng.uniform(0.015, 0.055)


def create_default_sensors() -> List[SensorStream]:
    """Create the three default environmental sensor streams."""

    return [
        SensorStream(
            name="Temperature",
            period=0.5,
            threshold=30.0,
            base_value=27.0,
            amplitude=5.0,
            frequency=0.04,
            phase=0.0
        ),

        SensorStream(
            name="Humidity",
            period=1.0,
            threshold=70.0,
            base_value=65.0,
            amplitude=10.0,
            frequency=0.025,
            phase=0.5
        ),

        SensorStream(
            name="Air Quality",
            period=2.0,
            threshold=100.0,
            base_value=90.0,
            amplitude=20.0,
            frequency=0.015,
            phase=0.3
        )
    ]


def create_four_sensor_load() -> List[SensorStream]:
    """
    Create a heavier workload by adding a fourth,
    faster environmental sensor.
    """

    sensors = create_default_sensors()

    sensors.append(
        SensorStream(
            name="Light Intensity",
            period=0.25,
            threshold=800.0,
            base_value=700.0,
            amplitude=150.0,
            frequency=0.035,
            phase=0.2
        )
    )

    return sensors
