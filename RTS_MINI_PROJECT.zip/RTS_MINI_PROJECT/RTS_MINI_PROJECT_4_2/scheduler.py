
"""
Mini Project 4.2
Multi-Rate Environmental Monitoring Pipeline

Implements:
1. Earliest Deadline First (EDF) scheduling.
2. Fixed-priority scheduling.
3. Random processing times with occasional long delays.
4. On-time, late, and missed job classification.
5. Threshold alert detection.
6. Per-sensor timing statistics.
"""

import random

from alert_system import AlertSystem


class MultiRateScheduler:
    """Schedules independent periodic environmental sensor jobs."""

    def __init__(
        self,
        sensors,
        policy="EDF",
        duration=30.0,
        seed=42
    ):
        self.sensors = sensors
        self.policy = policy.upper()
        self.duration = duration

        self.rng = random.Random(seed)
        self.alert_system = AlertSystem()

        self.clock = 0.0
        self.pending_jobs = []
        self.events = []

        self.job_number = 0

        if self.policy not in ("EDF", "FIXED_PRIORITY"):
            raise ValueError(
                "Policy must be EDF or FIXED_PRIORITY."
            )

        # Initialize each sensor's scheduling and reporting data.
        self.next_release = {}

        for sensor in self.sensors:
            sensor.next_due = 0.0
            sensor.last_sample_time = None

            sensor.sample_times.clear()
            sensor.sample_values.clear()
            sensor.sample_status.clear()

            sensor.required_samples = 0
            sensor.on_time_samples = 0
            sensor.late_samples = 0
            sensor.missed_samples = 0
            sensor.period_overruns.clear()
            sensor.alerts.clear()

            sensor.previous_value = None

            # Stores release times of jobs that were missed.
            sensor.missed_times = []

            self.next_release[sensor.name] = 0.0

    def release_due_jobs(self):
        """
        Release all jobs whose scheduled release time
        has arrived.
        """

        tolerance = 1e-9

        for sensor in self.sensors:

            release_time = self.next_release[sensor.name]

            while (
                release_time <= self.clock + tolerance
                and release_time <= self.duration + tolerance
            ):

                deadline = release_time + sensor.period

                job = {
                    "number": self.job_number,
                    "sensor": sensor,
                    "release": release_time,
                    "deadline": deadline
                }

                self.pending_jobs.append(job)

                sensor.required_samples += 1

                self.job_number += 1

                release_time += sensor.period

            self.next_release[sensor.name] = release_time

    def mark_expired_jobs(self):
        """
        Mark a job as missed if its deadline has passed
        before processing has started.
        """

        tolerance = 1e-9
        remaining_jobs = []

        for job in self.pending_jobs:

            sensor = job["sensor"]

            if self.clock > job["deadline"] + tolerance:

                sensor.missed_samples += 1
                sensor.missed_times.append(job["release"])

                self.events.append({
                    "sensor": sensor.name,
                    "job_number": job["number"],
                    "release": job["release"],
                    "deadline": job["deadline"],
                    "start": None,
                    "completion": None,
                    "processing_time": 0.0,
                    "overrun": None,
                    "status": "MISSED"
                })

            else:
                remaining_jobs.append(job)

        self.pending_jobs = remaining_jobs

    def select_next_job(self):
        """Choose one pending job according to the policy."""

        if not self.pending_jobs:
            return None

        if self.policy == "EDF":

            # Earliest absolute deadline first.
            selected = min(
                self.pending_jobs,
                key=lambda job: (
                    job["deadline"],
                    job["release"],
                    job["sensor"].name
                )
            )

        else:

            # Shortest sampling period gets highest priority.
            selected = min(
                self.pending_jobs,
                key=lambda job: (
                    job["sensor"].period,
                    job["release"],
                    job["sensor"].name
                )
            )

        self.pending_jobs.remove(selected)

        return selected

    def service_job(self, job):
        """Process one sensor job and record its timing result."""

        sensor = job["sensor"]

        start_time = self.clock

        processing_time = sensor.processing_time(self.rng)

        completion_time = start_time + processing_time

        deadline = job["deadline"]

        overrun = max(0.0, completion_time - deadline)

        if completion_time <= deadline + 1e-9:
            status = "ON_TIME"

            sensor.on_time_samples += 1

        else:
            status = "LATE"

            sensor.late_samples += 1

        sensor.period_overruns.append(overrun)

        # Record the actual completed sensor reading.
        measured_value = sensor.signal_value(completion_time)

        sensor.sample_times.append(completion_time)
        sensor.sample_values.append(measured_value)
        sensor.sample_status.append(status)

        sensor.last_sample_time = completion_time

        # Check for threshold alerts.
        self.alert_system.process_sample(
            sensor,
            completion_time,
            measured_value
        )

        self.events.append({
            "sensor": sensor.name,
            "job_number": job["number"],
            "release": job["release"],
            "deadline": deadline,
            "start": start_time,
            "completion": completion_time,
            "processing_time": processing_time,
            "overrun": overrun,
            "status": status
        })

        # The scheduler is non-preemptive.
        self.clock = completion_time

    def advance_to_next_release(self):
        """
        If no jobs are pending, advance simulated time
        to the next sensor release.
        """

        future_releases = [
            release
            for release in self.next_release.values()
            if release <= self.duration + 1e-9
        ]

        if not future_releases:
            return False

        next_time = min(future_releases)

        if next_time > self.clock:
            self.clock = next_time

        return True

    def run(self):
        """Execute the complete multi-rate scheduling simulation."""

        print("\n" + "=" * 70)
        print("MULTI-RATE ENVIRONMENTAL MONITORING SCHEDULER")
        print("=" * 70)

        print(f"Scheduling policy : {self.policy}")
        print(f"Simulation duration: {self.duration:.2f} seconds")
        print(f"Number of sensors  : {len(self.sensors)}")

        for sensor in self.sensors:
            print(
                f"  {sensor.name:<20} "
                f"Period: {sensor.period:.2f}s"
            )

        print("-" * 70)

        max_iterations = 100000
        iterations = 0

        while iterations < max_iterations:

            iterations += 1

            # Step 1: Release jobs that are due.
            self.release_due_jobs()

            # Step 2: Identify jobs whose deadlines have passed.
            self.mark_expired_jobs()

            # Step 3: Select one job.
            job = self.select_next_job()

            if job is not None:

                # Step 4: Process the selected job.
                self.service_job(job)

                continue

            # No pending job: advance to the next release.
            if not self.advance_to_next_release():
                break

        else:
            raise RuntimeError(
                "Maximum scheduler iterations exceeded."
            )

        print("\nSimulation completed.")
        print(f"Final simulated time: {self.clock:.3f} seconds")
        print(f"Total scheduling events: {len(self.events)}")

        return {
            "policy": self.policy,
            "duration": self.duration,
            "sensors": self.sensors,
            "events": self.events,
            "alerts": self.alert_system.get_all_alerts(
                self.sensors
            ),
            "final_time": self.clock
        }
