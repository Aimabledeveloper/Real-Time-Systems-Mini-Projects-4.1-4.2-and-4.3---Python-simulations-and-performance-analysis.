
import csv
import statistics
from pathlib import Path

import matplotlib.pyplot as plt


# ============================================================
# REAL-TIME SYSTEMS MINI PROJECT 4.1
# PART 7: PERFORMANCE EVALUATION
# ============================================================

INPUT_FILE = Path("results/part5/experimental_results.csv")
OUTPUT_DIR = Path("results/part7")

NOMINAL_PERIOD = 0.05

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# 1. LOAD EXPERIMENTAL DATA
# ============================================================

def load_data():

    if not INPUT_FILE.exists():
        raise FileNotFoundError(
            f"Experimental data not found: {INPUT_FILE}\n"
            "Please run part5_experiments.py first."
        )

    with INPUT_FILE.open(
        "r", newline="", encoding="utf-8"
    ) as file:

        reader = csv.DictReader(file)
        data = list(reader)

    if not data:
        raise ValueError("The experimental CSV file is empty.")

    required_columns = {
        "experiment",
        "condition",
    }

    missing = required_columns - set(data[0].keys())

    if missing:
        raise ValueError(
            f"Missing required CSV columns: {sorted(missing)}"
        )

    print("\nEXPERIMENTAL DATA LOADED")
    print(f"Source: {INPUT_FILE}")
    print(f"Total records: {len(data)}")

    return data


# ============================================================
# 2. GROUP EXPERIMENTAL DATA
# ============================================================

def group_data(data):

    groups = {}

    for row in data:

        experiment = row["experiment"].strip()
        condition = row["condition"].strip()

        key = (experiment, condition)

        groups.setdefault(key, []).append(row)

    return groups


def get_values(rows, column):

    values = []

    for row in rows:

        value = row.get(column, "")

        if value is None or value == "":
            continue

        try:
            values.append(float(value))

        except (ValueError, TypeError):
            continue

    return values


def average_metric(rows, column):

    values = get_values(rows, column)

    if not values:
        return None

    return statistics.mean(values)


def format_value(value, suffix=""):

    if value is None:
        return "N/A"

    return f"{value:.6f}{suffix}"


def matches_experiment(experiment, keyword):

    return keyword.lower() in experiment.strip().lower()


# ============================================================
# 3. SAVE A PERFORMANCE RESULT
# ============================================================

def add_result(
    results,
    category,
    condition,
    metric,
    value,
    unit,
    assessment
):

    results.append({

        "category": category,

        "condition": condition,

        "metric": metric,

        "value": (
            round(value, 8)
            if value is not None
            else ""
        ),

        "unit": unit,

        "assessment": assessment

    })


# ============================================================
# 4. PART 7A: SAMPLING JITTER PERFORMANCE
# ============================================================

def evaluate_jitter(groups, results):

    print("\n" + "=" * 75)
    print("PART 7A: SAMPLING JITTER PERFORMANCE")
    print("=" * 75)

    found = False

    for (experiment, condition), rows in groups.items():

        if not matches_experiment(experiment, "jitter"):
            continue

        found = True

        mean_interval = average_metric(
            rows, "mean_interval_s"
        )

        std_interval = average_metric(
            rows, "std_interval_s"
        )

        minimum_interval = average_metric(
            rows, "minimum_interval_s"
        )

        maximum_interval = average_metric(
            rows, "maximum_interval_s"
        )

        print(f"\nConfiguration: {condition}")

        print(
            "Mean sampling interval:",
            format_value(mean_interval, " seconds")
        )

        print(
            "Interval standard deviation:",
            format_value(std_interval, " seconds")
        )

        print(
            "Minimum sampling interval:",
            format_value(minimum_interval, " seconds")
        )

        print(
            "Maximum sampling interval:",
            format_value(maximum_interval, " seconds")
        )

        if std_interval is not None:

            if std_interval <= 0.001:
                assessment = "Very low timing variability"

            elif std_interval <= 0.005:
                assessment = "Moderate timing variability"

            else:
                assessment = "High timing variability"

            add_result(
                results,
                "Sampling Jitter",
                condition,
                "Interval standard deviation",
                std_interval,
                "seconds",
                assessment
            )

        if mean_interval is not None:

            deviation = mean_interval - NOMINAL_PERIOD

            add_result(
                results,
                "Sampling Jitter",
                condition,
                "Mean interval deviation",
                deviation,
                "seconds",
                "Difference from nominal sampling period"
            )

    if not found:
        print("No sampling jitter experiments found.")


# ============================================================
# 5. PART 7B: PROCESSING OVERRUN PERFORMANCE
# ============================================================

def evaluate_overruns(groups, results):

    print("\n" + "=" * 75)
    print("PART 7B: PROCESSING OVERRUN PERFORMANCE")
    print("=" * 75)

    found = False

    for (experiment, condition), rows in groups.items():

        if not matches_experiment(experiment, "overrun"):
            continue

        found = True

        overrun_rate = average_metric(
            rows, "overrun_rate_pct"
        )

        processing_time = average_metric(
            rows, "mean_processing_s"
        )

        sampling_interval = average_metric(
            rows, "mean_interval_s"
        )

        max_overrun = average_metric(
            rows, "max_overrun_s"
        )

        print(f"\nConfiguration: {condition}")

        print(
            "Actual overrun rate:",
            format_value(overrun_rate, "%")
        )

        print(
            "Mean processing time:",
            format_value(processing_time, " seconds")
        )

        print(
            "Mean sampling interval:",
            format_value(sampling_interval, " seconds")
        )

        print(
            "Mean maximum overrun:",
            format_value(max_overrun, " seconds")
        )

        if overrun_rate is not None:

            if overrun_rate == 0:
                assessment = "No processing overruns observed"

            elif overrun_rate <= 10:
                assessment = "Low observed overrun rate"

            else:
                assessment = "Elevated observed overrun rate"

            add_result(
                results,
                "Processing Overrun",
                condition,
                "Actual overrun rate",
                overrun_rate,
                "%",
                assessment
            )

        if sampling_interval is not None:

            add_result(
                results,
                "Processing Overrun",
                condition,
                "Mean sampling interval",
                sampling_interval,
                "seconds",
                "Compare with the nominal 0.05-second period"
            )

    if not found:
        print("No processing overrun experiments found.")


# ============================================================
# 6. PART 7C: CONTROLLER PERFORMANCE
# ============================================================

def evaluate_controller(groups, results):

    print("\n" + "=" * 75)
    print("PART 7C: CONTROLLER PERFORMANCE")
    print("=" * 75)

    found = False

    for (experiment, condition), rows in groups.items():

        if not matches_experiment(experiment, "controller"):
            continue

        found = True

        mean_delay = average_metric(
            rows, "mean_delay_s"
        )

        max_absolute_delay = average_metric(
            rows, "maximum_absolute_delay_s"
        )

        matched_crossings = average_metric(
            rows, "matched_crossings"
        )

        print(f"\nConfiguration: {condition}")

        print(
            "Mean actuation delay:",
            format_value(mean_delay, " seconds")
        )

        print(
            "Mean maximum absolute delay:",
            format_value(max_absolute_delay, " seconds")
        )

        print(
            "Mean matched crossings:",
            format_value(matched_crossings)
        )

        if mean_delay is not None:

            if mean_delay > 0:
                assessment = (
                    "Realistic controller was later on average"
                )

            elif mean_delay < 0:
                assessment = (
                    "Realistic controller was earlier on average"
                )

            else:
                assessment = "Zero average delay"

            add_result(
                results,
                "Controller",
                condition,
                "Mean actuation delay",
                mean_delay,
                "seconds",
                assessment
            )

        if max_absolute_delay is not None:

            add_result(
                results,
                "Controller",
                condition,
                "Mean maximum absolute delay",
                max_absolute_delay,
                "seconds",
                "Average of the five run-level maximum delays"
            )

    if not found:
        print("No controller experiments found.")


# ============================================================
# 7. SAVE PERFORMANCE RESULTS TO CSV
# ============================================================

def save_results(results):

    if not results:

        raise ValueError(
            "No performance results were generated. "
            "Check experiment names and CSV columns."
        )

    output_file = OUTPUT_DIR / "performance_evaluation.csv"

    fieldnames = [
        "category",
        "condition",
        "metric",
        "value",
        "unit",
        "assessment"
    ]

    with output_file.open(
        "w",
        newline="",
        encoding="utf-8"
    ) as file:

        writer = csv.DictWriter(
            file,
            fieldnames=fieldnames
        )

        writer.writeheader()
        writer.writerows(results)

    print("\nPERFORMANCE RESULTS SAVED")
    print(output_file)


# ============================================================
# 8. GENERATE PERFORMANCE GRAPHS
# ============================================================

def generate_graphs(groups):

    # --------------------------------------------------------
    # GRAPH 1: SAMPLING JITTER
    # --------------------------------------------------------

    jitter_labels = []
    jitter_values = []

    for (experiment, condition), rows in groups.items():

        if matches_experiment(experiment, "jitter"):

            value = average_metric(
                rows, "std_interval_s"
            )

            if value is not None:

                jitter_labels.append(condition)
                jitter_values.append(value)

    if jitter_values:

        plt.figure(figsize=(9, 5))

        plt.bar(
            jitter_labels,
            jitter_values
        )

        plt.title("Sampling Jitter Performance")

        plt.xlabel("Jitter Configuration")

        plt.ylabel(
            "Interval Standard Deviation (seconds)"
        )

        plt.grid(
            axis="y",
            alpha=0.3
        )

        plt.tight_layout()

        path = (
            OUTPUT_DIR /
            "sampling_jitter_performance.png"
        )

        plt.savefig(path, dpi=300)
        plt.close()

        print(f"Graph saved: {path}")

    # --------------------------------------------------------
    # GRAPH 2: PROCESSING OVERRUNS
    # --------------------------------------------------------

    overrun_labels = []
    overrun_values = []

    for (experiment, condition), rows in groups.items():

        if matches_experiment(experiment, "overrun"):

            value = average_metric(
                rows, "overrun_rate_pct"
            )

            if value is not None:

                overrun_labels.append(condition)
                overrun_values.append(value)

    if overrun_values:

        plt.figure(figsize=(9, 5))

        plt.bar(
            overrun_labels,
            overrun_values
        )

        plt.title("Processing Overrun Performance")

        plt.xlabel("Overrun Configuration")

        plt.ylabel("Actual Overrun Rate (%)")

        plt.grid(
            axis="y",
            alpha=0.3
        )

        plt.tight_layout()

        path = (
            OUTPUT_DIR /
            "processing_overrun_performance.png"
        )

        plt.savefig(path, dpi=300)
        plt.close()

        print(f"Graph saved: {path}")

    # --------------------------------------------------------
    # GRAPH 3: CONTROLLER DELAY
    # --------------------------------------------------------

    controller_labels = []
    controller_values = []

    for (experiment, condition), rows in groups.items():

        if matches_experiment(experiment, "controller"):

            value = average_metric(
                rows, "maximum_absolute_delay_s"
            )

            if value is not None:

                controller_labels.append(condition)
                controller_values.append(value)

    if controller_values:

        plt.figure(figsize=(12, 6))

        plt.bar(
            controller_labels,
            controller_values
        )

        plt.title(
            "Controller Maximum Absolute Actuation Delay"
        )

        plt.xlabel(
            "Jitter and Overrun Configuration"
        )

        plt.ylabel(
            "Mean Maximum Absolute Delay (seconds)"
        )

        plt.xticks(
            rotation=35,
            ha="right"
        )

        plt.grid(
            axis="y",
            alpha=0.3
        )

        plt.tight_layout()

        path = (
            OUTPUT_DIR /
            "controller_delay_performance.png"
        )

        plt.savefig(path, dpi=300)
        plt.close()

        print(f"Graph saved: {path}")


# ============================================================
# 9. GENERATE PERFORMANCE CONCLUSION
# ============================================================

def generate_conclusion(groups):

    jitter_std = []
    overrun_rates = []
    controller_delays = []

    for (experiment, condition), rows in groups.items():

        if matches_experiment(experiment, "jitter"):

            value = average_metric(
                rows, "std_interval_s"
            )

            if value is not None:
                jitter_std.append((condition, value))

        elif matches_experiment(experiment, "overrun"):

            value = average_metric(
                rows, "overrun_rate_pct"
            )

            if value is not None:
                overrun_rates.append((condition, value))

        elif matches_experiment(experiment, "controller"):

            value = average_metric(
                rows, "maximum_absolute_delay_s"
            )

            if value is not None:
                controller_delays.append((condition, value))

    report = []

    report.append(
        "REAL-TIME SYSTEMS MINI PROJECT 4.1"
    )

    report.append(
        "PART 7: PERFORMANCE EVALUATION"
    )

    report.append("=" * 65)

    # --------------------------------------------------------
    # SAMPLING JITTER
    # --------------------------------------------------------

    report.append("\n1. SAMPLING JITTER")

    if jitter_std:

        highest = max(
            jitter_std,
            key=lambda item: item[1]
        )

        report.append(
            f"Highest interval variability: "
            f"{highest[0]} "
            f"({highest[1]:.6f} seconds)"
        )

    else:

        report.append(
            "No sampling jitter results available."
        )

    # --------------------------------------------------------
    # PROCESSING OVERRUNS
    # --------------------------------------------------------

    report.append("\n2. PROCESSING OVERRUNS")

    if overrun_rates:

        highest = max(
            overrun_rates,
            key=lambda item: item[1]
        )

        report.append(
            f"Highest actual overrun rate: "
            f"{highest[0]} "
            f"({highest[1]:.2f}%)"
        )

    else:

        report.append(
            "No processing overrun results available."
        )

    # --------------------------------------------------------
    # CONTROLLER PERFORMANCE
    # --------------------------------------------------------

    report.append("\n3. CONTROLLER PERFORMANCE")

    if controller_delays:

        highest = max(
            controller_delays,
            key=lambda item: item[1]
        )

        report.append(
            f"Highest mean maximum absolute delay: "
            f"{highest[0]} "
            f"({highest[1]:.6f} seconds)"
        )

    else:

        report.append(
            "No controller results available."
        )

    # --------------------------------------------------------
    # SYSTEM LIMITATIONS
    # --------------------------------------------------------

    report.append("\n4. SYSTEM LIMITATIONS")

    report.append(
        "- The simulation uses a simplified processing model."
    )

    report.append(
        "- Processing time is added after each sampling event."
    )

    report.append(
        "- Therefore, the average sampling interval can exceed "
        "the nominal period even without overruns."
    )

    report.append(
        "- Controller crossings are matched by their order."
    )

    report.append(
        "- Results are based on five experimental runs per "
        "configuration."
    )

    # --------------------------------------------------------
    # RECOMMENDATIONS
    # --------------------------------------------------------

    report.append("\n5. RECOMMENDATIONS")

    report.append(
        "- Reduce processing time to improve timing performance."
    )

    report.append(
        "- Monitor sampling jitter and processing overruns."
    )

    report.append(
        "- Use deadline monitoring in a real-time implementation."
    )

    report.append(
        "- Increase the number of experimental runs for stronger "
        "statistical evidence."
    )

    report_text = "\n".join(report)

    output_file = (
        OUTPUT_DIR / "performance_conclusion.txt"
    )

    output_file.write_text(
        report_text,
        encoding="utf-8"
    )

    print("\n" + "=" * 75)
    print(report_text)

    print("\nConclusion saved:")
    print(output_file)


# ============================================================
# 10. MAIN PROGRAM
# ============================================================

def main():

    print("\n" + "=" * 75)

    print(
        "REAL-TIME SYSTEMS MINI PROJECT 4.1"
    )

    print(
        "PART 7: PERFORMANCE EVALUATION"
    )

    print("=" * 75)

    data = load_data()

    groups = group_data(data)

    print("\nEXPERIMENT CATEGORIES FOUND:")

    for experiment, condition in groups:

        print(
            f"- {experiment}: {condition}"
        )

    results = []

    evaluate_jitter(
        groups,
        results
    )

    evaluate_overruns(
        groups,
        results
    )

    evaluate_controller(
        groups,
        results
    )

    if not results:

        raise ValueError(
            "No performance results were generated. "
            "Check the experiment names and metric columns "
            "in experimental_results.csv."
        )

    save_results(results)

    generate_graphs(groups)

    generate_conclusion(groups)

    print("\n" + "=" * 75)

    print(
        "PART 7 COMPLETED SUCCESSFULLY!"
    )

    print("=" * 75)

    print(
        f"Output directory: {OUTPUT_DIR}"
    )


if __name__ == "__main__":

    main()
