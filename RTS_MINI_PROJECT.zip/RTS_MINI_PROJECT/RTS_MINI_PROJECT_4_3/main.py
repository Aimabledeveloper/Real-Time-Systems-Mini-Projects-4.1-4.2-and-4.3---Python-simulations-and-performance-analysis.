
"""
REAL-TIME SYSTEMS - MINI PROJECT 4.3

Edge-versus-Cloud Latency Simulator

Main experiment runner:
1. Compares Edge, Cloud and Hybrid architectures.
2. Tests multiple cloud congestion levels.
3. Generates latency distribution figure.
4. Generates congestion compliance figure.
5. Saves CSV reports and figures.
"""

import csv
import os
import matplotlib.pyplot as plt

from edge_cloud_models import EdgeCloudConfig
from simulation import run_simulation
from hybrid_policy import run_hybrid_simulation
from performance_analysis import (
    run_all_architectures,
    print_comparison_table,
    save_comparison_csv,
    analyze_events
)


# ============================================================
# EXPERIMENT CONFIGURATION
# ============================================================

NUMBER_OF_EVENTS = 10000
CONGESTION_LEVEL = 0.50
HARD_DECISION_PROBABILITY = 0.15
SAMPLING_PERIOD_MS = 50.0
RANDOM_SEED = 42

CONGESTION_LEVELS = [
    0.0,
    0.25,
    0.50,
    0.75,
    1.0
]

RESULTS_DIR = "results"
REPORTS_DIR = os.path.join(RESULTS_DIR, "reports")
FIGURES_DIR = os.path.join(RESULTS_DIR, "figures")


def create_directories():
    """Create output folders."""

    os.makedirs(REPORTS_DIR, exist_ok=True)
    os.makedirs(FIGURES_DIR, exist_ok=True)


# ============================================================
# CSV EXPORT
# ============================================================

def save_congestion_results(results):
    """Save cloud congestion experiment results."""

    output_path = os.path.join(
        REPORTS_DIR,
        "congestion_analysis.csv"
    )

    fieldnames = [
        "congestion_level",
        "edge_compliance_percentage",
        "cloud_compliance_percentage",
        "cloud_mean_latency_ms",
        "cloud_p95_latency_ms",
        "cloud_p99_latency_ms",
        "cloud_worst_case_latency_ms"
    ]

    with open(
        output_path,
        "w",
        newline="",
        encoding="utf-8"
    ) as file:

        writer = csv.DictWriter(
            file,
            fieldnames=fieldnames
        )

        writer.writeheader()
        writer.writerows(results)

    print(f"Congestion report saved: {output_path}")


# ============================================================
# FIGURE 1: LATENCY DISTRIBUTIONS
# ============================================================

def generate_latency_distribution_figure(
    edge_events,
    cloud_events,
    hybrid_events,
    deadline_ms
):
    """
    Generate overlaid latency distributions
    for Edge, Cloud and Hybrid architectures.
    """

    edge_latencies = [
        event.total_latency_ms
        for event in edge_events
    ]

    cloud_latencies = [
        event.total_latency_ms
        for event in cloud_events
    ]

    hybrid_latencies = [
        event.total_latency_ms
        for event in hybrid_events
    ]

    plt.figure(figsize=(12, 7))

    plt.hist(
        edge_latencies,
        bins=50,
        alpha=0.55,
        density=True,
        label="Edge"
    )

    plt.hist(
        cloud_latencies,
        bins=50,
        alpha=0.45,
        density=True,
        label="Cloud"
    )

    plt.hist(
        hybrid_latencies,
        bins=50,
        alpha=0.45,
        density=True,
        label="Hybrid"
    )

    plt.axvline(
        deadline_ms,
        linestyle="--",
        linewidth=2,
        label=f"Deadline ({deadline_ms:.0f} ms)"
    )

    plt.title(
        "Edge, Cloud and Hybrid Latency Distributions"
    )

    plt.xlabel("End-to-End Latency (milliseconds)")
    plt.ylabel("Probability Density")

    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.tight_layout()

    output_path = os.path.join(
        FIGURES_DIR,
        "latency_distributions.png"
    )

    plt.savefig(
        output_path,
        dpi=300,
        bbox_inches="tight"
    )

    plt.close()

    print(f"Latency figure saved: {output_path}")


# ============================================================
# FIGURE 2: CONGESTION VS DEADLINE COMPLIANCE
# ============================================================

def generate_congestion_figure(congestion_results):
    """
    Plot cloud deadline compliance against congestion.

    Edge compliance is included as a flat reference.
    """

    congestion_percentages = [
        item["congestion_level"] * 100
        for item in congestion_results
    ]

    cloud_compliance = [
        item["cloud_compliance_percentage"]
        for item in congestion_results
    ]

    edge_compliance = [
        item["edge_compliance_percentage"]
        for item in congestion_results
    ]

    plt.figure(figsize=(10, 6))

    plt.plot(
        congestion_percentages,
        cloud_compliance,
        marker="o",
        linewidth=2,
        label="Cloud compliance"
    )

    plt.plot(
        congestion_percentages,
        edge_compliance,
        linestyle="--",
        marker="s",
        linewidth=2,
        label="Edge reference"
    )

    plt.xlabel("Cloud Congestion Level (%)")
    plt.ylabel("Deadline Compliance (%)")

    plt.title(
        "Deadline Compliance Under Different Cloud Congestion Levels"
    )

    plt.xticks(congestion_percentages)
    plt.ylim(0, 105)

    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.tight_layout()

    output_path = os.path.join(
        FIGURES_DIR,
        "congestion_vs_compliance.png"
    )

    plt.savefig(
        output_path,
        dpi=300,
        bbox_inches="tight"
    )

    plt.close()

    print(f"Congestion figure saved: {output_path}")


# ============================================================
# CONGESTION EXPERIMENT
# ============================================================

def run_congestion_experiments(config):
    """Evaluate Cloud performance at different congestion levels."""

    results = []

    print("\n" + "=" * 75)
    print("CLOUD CONGESTION EXPERIMENT")
    print("=" * 75)

    print(
        f"{'Congestion':<15}"
        f"{'Edge Compliance':>20}"
        f"{'Cloud Compliance':>22}"
        f"{'Cloud Mean (ms)':>18}"
    )

    print("-" * 75)

    for index, congestion in enumerate(CONGESTION_LEVELS):

        events = run_simulation(
            number_of_events=NUMBER_OF_EVENTS,
            sampling_period_ms=SAMPLING_PERIOD_MS,
            congestion_level=congestion,
            seed=RANDOM_SEED,
            config=config
        )

        edge_events = [
            event for event in events
            if event.execution_mode == "EDGE"
        ]

        cloud_events = [
            event for event in events
            if event.execution_mode == "CLOUD"
        ]

        edge_metrics = analyze_events(
            edge_events,
            "EDGE"
        )

        cloud_metrics = analyze_events(
            cloud_events,
            "CLOUD"
        )

        row = {
            "congestion_level": congestion,
            "edge_compliance_percentage":
                edge_metrics["compliance_percentage"],
            "cloud_compliance_percentage":
                cloud_metrics["compliance_percentage"],
            "cloud_mean_latency_ms":
                cloud_metrics["mean_latency_ms"],
            "cloud_p95_latency_ms":
                cloud_metrics["p95_latency_ms"],
            "cloud_p99_latency_ms":
                cloud_metrics["p99_latency_ms"],
            "cloud_worst_case_latency_ms":
                cloud_metrics["worst_case_latency_ms"]
        }

        results.append(row)

        print(
            f"{congestion * 100:<14.0f}%"
            f"{row['edge_compliance_percentage']:>19.2f}%"
            f"{row['cloud_compliance_percentage']:>21.2f}%"
            f"{row['cloud_mean_latency_ms']:>18.2f}"
        )

    print("=" * 75)

    return results


# ============================================================
# MAIN PROGRAM
# ============================================================

def main():

    create_directories()

    config = EdgeCloudConfig(
        deadline_ms=100.0
    )

    print("\n" + "=" * 75)
    print("REAL-TIME SYSTEMS - MINI PROJECT 4.3")
    print("EDGE-VERSUS-CLOUD LATENCY SIMULATOR")
    print("=" * 75)

    print(f"Number of events       : {NUMBER_OF_EVENTS}")
    print(f"Sampling period        : {SAMPLING_PERIOD_MS} ms")
    print(f"Decision deadline      : {config.deadline_ms} ms")
    print(f"Cloud congestion       : {CONGESTION_LEVEL * 100:.0f}%")
    print(
        f"Hybrid cloud fallback : "
        f"{HARD_DECISION_PROBABILITY * 100:.0f}%"
    )
    print(f"Random seed            : {RANDOM_SEED}")

    # --------------------------------------------------------
    # Experiment 1: Compare three architectures
    # --------------------------------------------------------

    print("\nRunning Edge, Cloud and Hybrid comparison...")

    comparison_results = run_all_architectures(
        number_of_events=NUMBER_OF_EVENTS,
        sampling_period_ms=SAMPLING_PERIOD_MS,
        congestion_level=CONGESTION_LEVEL,
        hard_decision_probability=HARD_DECISION_PROBABILITY,
        seed=RANDOM_SEED,
        config=config
    )

    print_comparison_table(comparison_results)

    save_comparison_csv(
        comparison_results,
        os.path.join(
            REPORTS_DIR,
            "architecture_comparison.csv"
        )
    )

    # --------------------------------------------------------
    # Experiment 2: Generate latency distribution data
    # --------------------------------------------------------

    print("\nGenerating latency distribution data...")

    baseline_events = run_simulation(
        number_of_events=NUMBER_OF_EVENTS,
        sampling_period_ms=SAMPLING_PERIOD_MS,
        congestion_level=CONGESTION_LEVEL,
        seed=RANDOM_SEED,
        config=config
    )

    edge_events = [
        event for event in baseline_events
        if event.execution_mode == "EDGE"
    ]

    cloud_events = [
        event for event in baseline_events
        if event.execution_mode == "CLOUD"
    ]

    hybrid_events = run_hybrid_simulation(
        number_of_events=NUMBER_OF_EVENTS,
        sampling_period_ms=SAMPLING_PERIOD_MS,
        congestion_level=CONGESTION_LEVEL,
        hard_decision_probability=HARD_DECISION_PROBABILITY,
        seed=RANDOM_SEED,
        config=config
    )

    generate_latency_distribution_figure(
        edge_events,
        cloud_events,
        hybrid_events,
        config.deadline_ms
    )

    # --------------------------------------------------------
    # Experiment 3: Cloud congestion tests
    # --------------------------------------------------------

    congestion_results = run_congestion_experiments(
        config
    )

    save_congestion_results(
        congestion_results
    )

    generate_congestion_figure(
        congestion_results
    )

    # --------------------------------------------------------
    # Final output
    # --------------------------------------------------------

    print("\n" + "=" * 75)
    print("MINI PROJECT 4.3 COMPLETED SUCCESSFULLY")
    print("=" * 75)

    print("\nGENERATED REPORTS:")

    print(
        os.path.join(
            REPORTS_DIR,
            "architecture_comparison.csv"
        )
    )

    print(
        os.path.join(
            REPORTS_DIR,
            "congestion_analysis.csv"
        )
    )

    print("\nGENERATED FIGURES:")

    print(
        os.path.join(
            FIGURES_DIR,
            "latency_distributions.png"
        )
    )

    print(
        os.path.join(
            FIGURES_DIR,
            "congestion_vs_compliance.png"
        )
    )

    print("=" * 75)


if __name__ == "__main__":
    main()
