
# ============================================================
# REAL-TIME SYSTEMS - MINI PROJECT 4.1
# PART 5: EXPERIMENTAL COMPARISON
# Sampling Jitter, Processing Overruns and Controller Delays
# ============================================================

import csv
import statistics
from pathlib import Path

import matplotlib.pyplot as plt

from rt_sampling_sim import (
    T_NOMINAL,
    SIMULATION_DURATION,
    THRESHOLD,
    RANDOM_SEED,
    generate_jittered_samples,
    generate_overrun_samples,
    generate_ideal_samples,
    detect_actuations
)

# ============================================================
# 1. EXPERIMENTAL CONFIGURATION
# ============================================================

JITTER_LEVELS = [
    0.001,
    0.005,
    0.010
]

OVERRUN_LEVELS = [
    0.00,
    0.10,
    0.20
]

NUMBER_OF_RUNS = 5

EXPERIMENT_SEEDS = [
    RANDOM_SEED + i for i in range(NUMBER_OF_RUNS)
]

OUTPUT_DIR = Path("results/part5")
FIGURE_DIR = OUTPUT_DIR

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# 2. HELPER FUNCTIONS
# ============================================================

def safe_mean(values):

    return statistics.mean(values) if values else 0.0


def safe_std(values):

    if len(values) > 1:
        return statistics.stdev(values)

    return 0.0


def get_intervals(sample_times):

    return [
        sample_times[i] - sample_times[i - 1]
        for i in range(1, len(sample_times))
    ]


def get_delay_statistics(delays):

    if not delays:
        return {
            "mean": 0.0,
            "std": 0.0,
            "minimum": 0.0,
            "maximum": 0.0,
            "maximum_absolute": 0.0
        }

    return {
        "mean": statistics.mean(delays),
        "std": safe_std(delays),
        "minimum": min(delays),
        "maximum": max(delays),
        "maximum_absolute": max(abs(x) for x in delays)
    }


# ============================================================
# 3. EXPERIMENT A: SAMPLING JITTER COMPARISON
# ============================================================

def experiment_jitter():

    print("\n" + "=" * 65)
    print("PART 5A: SAMPLING JITTER COMPARISON")
    print("=" * 65)

    results = []

    for jitter_bound in JITTER_LEVELS:

        run_means = []
        run_stds = []
        run_minimums = []
        run_maximums = []

        for seed in EXPERIMENT_SEEDS:

            times, values, jitters = generate_jittered_samples(
                jitter_bound=jitter_bound,
                seed=seed
            )

            intervals = get_intervals(times)

            run_mean = safe_mean(intervals)
            run_std = safe_std(intervals)

            run_means.append(run_mean)
            run_stds.append(run_std)
            run_minimums.append(min(intervals))
            run_maximums.append(max(intervals))

            results.append({
                "experiment": "Sampling Jitter",
                "condition": f"Jitter +/- {jitter_bound:.3f}s",
                "jitter_bound_s": jitter_bound,
                "overrun_probability": "",
                "seed": seed,
                "cycles": len(times),
                "overrun_cycles": "",
                "overrun_rate_pct": "",
                "mean_interval_s": run_mean,
                "std_interval_s": run_std,
                "minimum_interval_s": min(intervals),
                "maximum_interval_s": max(intervals),
                "mean_processing_s": "",
                "max_overrun_s": "",
                "ideal_crossings": "",
                "realistic_crossings": "",
                "matched_crossings": "",
                "mean_delay_s": "",
                "std_delay_s": "",
                "minimum_delay_s": "",
                "maximum_delay_s": "",
                "maximum_absolute_delay_s": ""
            })

        print(f"\nJitter bound: +/- {jitter_bound:.3f} seconds")
        print(f"Mean interval: {safe_mean(run_means):.6f} seconds")
        print(f"Mean interval standard deviation: {safe_mean(run_stds):.6f} seconds")
        print(f"Minimum interval: {min(run_minimums):.6f} seconds")
        print(f"Maximum interval: {max(run_maximums):.6f} seconds")

    return results


# ============================================================
# 4. EXPERIMENT B: PROCESSING OVERRUN COMPARISON
# ============================================================

def experiment_overruns():

    print("\n" + "=" * 65)
    print("PART 5B: PROCESSING OVERRUN COMPARISON")
    print("=" * 65)

    results = []

    jitter_bound = 0.10 * T_NOMINAL

    for probability in OVERRUN_LEVELS:

        rates = []
        mean_processing_values = []
        maximum_overruns = []
        mean_intervals = []

        for seed in EXPERIMENT_SEEDS:

            (
                times,
                values,
                jitters,
                processing_times,
                overrun_flags
            ) = generate_overrun_samples(
                jitter_bound=jitter_bound,
                overrun_probability=probability,
                seed=seed
            )

            intervals = get_intervals(times)

            total_cycles = len(processing_times)

            overrun_count = sum(overrun_flags)

            overrun_rate = (
                100 * overrun_count / total_cycles
                if total_cycles else 0.0
            )

            mean_processing = safe_mean(processing_times)

            maximum_overrun = max(
                [max(0.0, x - T_NOMINAL) for x in processing_times],
                default=0.0
            )

            mean_interval = safe_mean(intervals)

            rates.append(overrun_rate)
            mean_processing_values.append(mean_processing)
            maximum_overruns.append(maximum_overrun)
            mean_intervals.append(mean_interval)

            results.append({
                "experiment": "Processing Overrun",
                "condition": f"Overrun {probability * 100:.0f}%",
                "jitter_bound_s": jitter_bound,
                "overrun_probability": probability,
                "seed": seed,
                "cycles": total_cycles,
                "overrun_cycles": overrun_count,
                "overrun_rate_pct": overrun_rate,
                "mean_interval_s": mean_interval,
                "std_interval_s": safe_std(intervals),
                "minimum_interval_s": min(intervals) if intervals else 0,
                "maximum_interval_s": max(intervals) if intervals else 0,
                "mean_processing_s": mean_processing,
                "max_overrun_s": maximum_overrun,
                "ideal_crossings": "",
                "realistic_crossings": "",
                "matched_crossings": "",
                "mean_delay_s": "",
                "std_delay_s": "",
                "minimum_delay_s": "",
                "maximum_delay_s": "",
                "maximum_absolute_delay_s": ""
            })

        print(f"\nOverrun probability: {probability * 100:.0f}%")
        print(f"Mean actual overrun rate: {safe_mean(rates):.2f}%")
        print(f"Mean processing time: {safe_mean(mean_processing_values):.6f} seconds")
        print(f"Mean maximum overrun: {safe_mean(maximum_overruns):.6f} seconds")
        print(f"Mean sampling interval: {safe_mean(mean_intervals):.6f} seconds")

    return results


# ============================================================
# 5. EXPERIMENT C: CONTROLLER PERFORMANCE COMPARISON
# ============================================================

def experiment_controller():

    print("\n" + "=" * 65)
    print("PART 5C: CONTROLLER PERFORMANCE COMPARISON")
    print("=" * 65)

    results = []

    ideal_times, ideal_values = generate_ideal_samples()

    ideal_actuations = detect_actuations(
        ideal_times,
        ideal_values,
        THRESHOLD
    )

    for jitter_bound in JITTER_LEVELS:

        for probability in OVERRUN_LEVELS:

            delay_values = []

            ideal_counts = []
            realistic_counts = []
            matched_counts = []

            for seed in EXPERIMENT_SEEDS:

                (
                    times,
                    values,
                    jitters,
                    processing,
                    overruns
                ) = generate_overrun_samples(
                    jitter_bound=jitter_bound,
                    overrun_probability=probability,
                    seed=seed
                )

                realistic_actuations = detect_actuations(
                    times,
                    values,
                    THRESHOLD
                )

                matched = min(
                    len(ideal_actuations),
                    len(realistic_actuations)
                )

                delays = [
                    realistic_actuations[i] - ideal_actuations[i]
                    for i in range(matched)
                ]

                stats = get_delay_statistics(delays)

                delay_values.extend(delays)

                ideal_counts.append(len(ideal_actuations))
                realistic_counts.append(len(realistic_actuations))
                matched_counts.append(matched)

                results.append({
                    "experiment": "Controller Performance",
                    "condition": (
                        f"Jitter +/- {jitter_bound:.3f}s, "
                        f"Overrun {probability * 100:.0f}%"
                    ),
                    "jitter_bound_s": jitter_bound,
                    "overrun_probability": probability,
                    "seed": seed,
                    "cycles": len(times),
                    "overrun_cycles": sum(overruns),
                    "overrun_rate_pct": (
                        100 * sum(overruns) / len(overruns)
                        if overruns else 0.0
                    ),
                    "mean_interval_s": safe_mean(get_intervals(times)),
                    "std_interval_s": safe_std(get_intervals(times)),
                    "minimum_interval_s": min(get_intervals(times)),
                    "maximum_interval_s": max(get_intervals(times)),
                    "mean_processing_s": safe_mean(processing),
                    "max_overrun_s": max(
                        [max(0.0, x - T_NOMINAL) for x in processing],
                        default=0.0
                    ),
                    "ideal_crossings": len(ideal_actuations),
                    "realistic_crossings": len(realistic_actuations),
                    "matched_crossings": matched,
                    "mean_delay_s": stats["mean"],
                    "std_delay_s": stats["std"],
                    "minimum_delay_s": stats["minimum"],
                    "maximum_delay_s": stats["maximum"],
                    "maximum_absolute_delay_s": stats["maximum_absolute"]
                })

            final_stats = get_delay_statistics(delay_values)

            print(
                f"\nJitter: +/- {jitter_bound:.3f}s | "
                f"Overrun: {probability * 100:.0f}%"
            )

            print(
                f"Average detected crossings: "
                f"{safe_mean(realistic_counts):.2f}"
            )

            print(
                f"Mean actuation delay: "
                f"{final_stats['mean']:.6f} seconds"
            )

            print(
                f"Maximum absolute delay: "
                f"{final_stats['maximum_absolute']:.6f} seconds"
            )

    return results


# ============================================================
# 6. SAVE EXPERIMENTAL RESULTS TO CSV
# ============================================================

def save_results_csv(all_results):

    output_file = OUTPUT_DIR / "experimental_results.csv"

    if not all_results:
        print("No experimental results available.")
        return

    fieldnames = list(all_results[0].keys())

    with open(
        output_file,
        "w",
        newline="",
        encoding="utf-8"
    ) as file:

        writer = csv.DictWriter(
            file,
            fieldnames=fieldnames
        )

        writer.writeheader()
        writer.writerows(all_results)

    print("\nCSV RESULTS SAVED")
    print(output_file)


# ============================================================
# 7. GRAPH A: JITTER COMPARISON
# ============================================================

def plot_jitter_comparison(jitter_results):

    means = []
    stds = []

    for level in JITTER_LEVELS:

        matching = [
            row for row in jitter_results
            if row["jitter_bound_s"] == level
        ]

        means.append(
            safe_mean([r["mean_interval_s"] for r in matching])
        )

        stds.append(
            safe_mean([r["std_interval_s"] for r in matching])
        )

    labels = [
        f"+/- {x:.3f}s" for x in JITTER_LEVELS
    ]

    fig, ax = plt.subplots(figsize=(10, 6))

    ax.bar(labels, stds)

    ax.set_title("Effect of Sampling Jitter on Timing Variation")
    ax.set_xlabel("Jitter Bound")
    ax.set_ylabel("Mean Standard Deviation (seconds)")

    ax.grid(True, axis="y")

    plt.tight_layout()

    path = FIGURE_DIR / "jitter_comparison.png"

    fig.savefig(path, dpi=300)
    plt.close(fig)

    print(f"Jitter graph saved: {path}")


# ============================================================
# 8. GRAPH B: PROCESSING OVERRUN COMPARISON
# ============================================================

def plot_overrun_comparison(overrun_results):

    probabilities = []

    actual_rates = []
    processing_means = []

    for probability in OVERRUN_LEVELS:

        matching = [
            row for row in overrun_results
            if row["overrun_probability"] == probability
        ]

        probabilities.append(
            f"{probability * 100:.0f}%"
        )

        actual_rates.append(
            safe_mean([r["overrun_rate_pct"] for r in matching])
        )

        processing_means.append(
            safe_mean([r["mean_processing_s"] for r in matching])
        )

    fig, axes = plt.subplots(1, 2, figsize=(13, 5))

    axes[0].bar(probabilities, actual_rates)

    axes[0].set_title("Actual Processing Overrun Rate")
    axes[0].set_xlabel("Configured Overrun Probability")
    axes[0].set_ylabel("Actual Overrun Rate (%)")
    axes[0].grid(True, axis="y")

    axes[1].bar(probabilities, processing_means)

    axes[1].set_title("Mean Processing Time")
    axes[1].set_xlabel("Configured Overrun Probability")
    axes[1].set_ylabel("Processing Time (seconds)")
    axes[1].grid(True, axis="y")

    fig.tight_layout()

    path = FIGURE_DIR / "overrun_comparison.png"

    fig.savefig(path, dpi=300)
    plt.close(fig)

    print(f"Overrun graph saved: {path}")


# ============================================================
# 9. GRAPH C: CONTROLLER PERFORMANCE COMPARISON
# ============================================================

def plot_controller_comparison(controller_results):

    fig, ax = plt.subplots(figsize=(12, 6))

    positions = list(range(len(OVERRUN_LEVELS)))

    width = 0.24

    for index, jitter in enumerate(JITTER_LEVELS):

        means = []

        for probability in OVERRUN_LEVELS:

            matching = [
                row for row in controller_results
                if row["jitter_bound_s"] == jitter
                and row["overrun_probability"] == probability
            ]

            means.append(
                safe_mean([
                    r["mean_delay_s"] for r in matching
                ])
            )

        offset = (
            index - (len(JITTER_LEVELS) - 1) / 2
        ) * width

        ax.bar(
            [p + offset for p in positions],
            means,
            width=width,
            label=f"Jitter +/- {jitter:.3f}s"
        )

    ax.set_xticks(positions)

    ax.set_xticklabels([
        f"{p * 100:.0f}%"
        for p in OVERRUN_LEVELS
    ])

    ax.set_title("Effect of Jitter and Overruns on Actuation Delay")
    ax.set_xlabel("Processing Overrun Probability")
    ax.set_ylabel("Mean Actuation Delay (seconds)")

    ax.axhline(y=0, linestyle="--")

    ax.legend()
    ax.grid(True, axis="y")

    plt.tight_layout()

    path = FIGURE_DIR / "controller_comparison.png"

    fig.savefig(path, dpi=300)
    plt.close(fig)

    print(f"Controller graph saved: {path}")


# ============================================================
# 10. MAIN EXPERIMENTAL PROGRAM
# ============================================================

if __name__ == "__main__":

    print("\n" + "=" * 65)
    print("REAL-TIME SYSTEMS MINI PROJECT 4.1")
    print("PART 5: EXPERIMENTAL COMPARISON")
    print("=" * 65)

    print(f"Nominal sampling period: {T_NOMINAL:.3f} seconds")
    print(f"Simulation duration: {SIMULATION_DURATION:.1f} seconds")
    print(f"Threshold: {THRESHOLD}")
    print(f"Experimental runs per configuration: {NUMBER_OF_RUNS}")

    # Run Experiment A
    jitter_results = experiment_jitter()

    # Run Experiment B
    overrun_results = experiment_overruns()

    # Run Experiment C
    controller_results = experiment_controller()

    # Combine all experimental records
    all_results = (
        jitter_results
        + overrun_results
        + controller_results
    )

    # Save experimental results
    save_results_csv(all_results)

    # Generate comparison graphs
    plot_jitter_comparison(jitter_results)

    plot_overrun_comparison(overrun_results)

    plot_controller_comparison(controller_results)

    print("\n" + "=" * 65)
    print("PART 5 EXPERIMENTS COMPLETED SUCCESSFULLY!")
    print("=" * 65)

    print(f"Results directory: {OUTPUT_DIR}")
