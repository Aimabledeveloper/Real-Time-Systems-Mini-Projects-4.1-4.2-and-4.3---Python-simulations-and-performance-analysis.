
# ============================================================
# REAL-TIME SYSTEMS - MINI PROJECT 4.1
# Sampling Jitter and Processing Overruns Simulation
# ============================================================

import math
import random
import statistics
import matplotlib.pyplot as plt

# ============================================================
# 1. SIMULATION CONFIGURATION
# ============================================================

T_NOMINAL = 0.05          # Sampling period in seconds
SIMULATION_DURATION = 20 
# Processing-time configuration
OVERRUN_PROBABILITY = 0.10

NORMAL_PROCESSING_MIN = 0.005
NORMAL_PROCESSING_MAX = 0.020

OVERRUN_PROCESSING_MIN = 0.055
OVERRUN_PROCESSING_MAX = 0.120 # Total simulation duration in seconds

SIGNAL_AMPLITUDE = 1.0
SIGNAL_PERIOD = 5.0

THRESHOLD = 0.5

# Random seed for reproducible experiments
RANDOM_SEED = 42

# Small continuous noise in the simulated signal
NOISE_AMPLITUDE = 0.02

# ============================================================
# 2. SIMULATED PHYSICAL SIGNAL
# ============================================================

def true_signal(t):
    """
    Generate a simulated physical signal.

    The signal consists of:
    - A sine wave
    - Small continuous noise

    Parameters:
        t: Simulation time in seconds

    Returns:
        Simulated sensor value
    """

    main_signal = SIGNAL_AMPLITUDE * math.sin(
        2 * math.pi * t / SIGNAL_PERIOD
    )

    noise = NOISE_AMPLITUDE * (
        0.6 * math.sin(2 * math.pi * 7 * t)
        + 0.4 * math.sin(2 * math.pi * 13 * t)
    )

    return main_signal + noise

# ============================================================
# 3. TEST AND VISUALIZE THE SIGNAL
# ============================================================

def test_signal():

    time_values = []
    signal_values = []

    # Generate signal values over 20 seconds
    number_of_points = int(
        SIMULATION_DURATION / 0.01
    ) + 1

    for i in range(number_of_points):

        t = i * 0.01

        time_values.append(t)
        signal_values.append(true_signal(t))

    # Display graph
    plt.figure(figsize=(12, 5))

    plt.plot(
        time_values,
        signal_values,
        label="True Physical Signal"
    )

    plt.axhline(
        y=THRESHOLD,
        linestyle="--",
        label="Controller Threshold"
    )

    plt.title("Simulated Physical Sensor Signal")

    plt.xlabel("Time (seconds)")
    plt.ylabel("Signal Value")

    plt.legend()
    plt.grid(True)

    plt.tight_layout(pad=2.5)


    # Save graph
    plt.savefig(
        "results/figures/signal_test.png",
        dpi=300
    )

    plt.show()

    print("Signal simulation completed successfully!")
    print("Graph saved in results/figures/signal_test.png")


# ============================================================

# ============================================================
# 4. IDEAL BASELINE SAMPLING
# ============================================================

def generate_ideal_samples():

    sample_times = []
    sample_values = []

    # Number of scheduled samples in 20 seconds
    number_of_samples = int(
        SIMULATION_DURATION / T_NOMINAL
    )

    for k in range(number_of_samples):

        # Exact scheduled sampling time
        t = k * T_NOMINAL

        value = true_signal(t)

        sample_times.append(t)
        sample_values.append(value)

    return sample_times, sample_values


# ============================================================
# 5. SAMPLING WITH RANDOM JITTER
# ============================================================

def generate_jittered_samples(jitter_bound, seed=RANDOM_SEED):

    sample_times = []
    sample_values = []
    jitter_values = []

    # Local random generator for repeatable results
    rng = random.Random(seed)

    number_of_samples = int(
        SIMULATION_DURATION / T_NOMINAL
    )

    for k in range(number_of_samples):

        # Scheduled sampling time
        scheduled_time = k * T_NOMINAL

        # Keep the first sample at time zero
        if k == 0:
            jitter = 0.0
        else:
            jitter = rng.uniform(
                -jitter_bound,
                jitter_bound
            )

        # Actual sampling time
        actual_time = scheduled_time + jitter

        # Read the simulated sensor
        value = true_signal(actual_time)

        sample_times.append(actual_time)
        sample_values.append(value)
        jitter_values.append(jitter)

    return sample_times, sample_values, jitter_values


# ============================================================
# 6. TEST IDEAL AND JITTERED SAMPLING
# ============================================================

def test_sampling_jitter():

    # Generate ideal samples
    ideal_times, ideal_values = generate_ideal_samples()

    # Generate jittered samples
    jitter_bound = 0.10 * T_NOMINAL

    jittered_times, jittered_values, jitter_values = (
        generate_jittered_samples(jitter_bound)
    )

    # Calculate actual intervals between jittered samples
    intervals = []

    for i in range(1, len(jittered_times)):

        interval = (
            jittered_times[i] - jittered_times[i - 1]
        )

        intervals.append(interval)

    # Calculate timing statistics
    mean_interval = statistics.mean(intervals)
    std_interval = statistics.stdev(intervals)

    print("\n========================================")
    print("IDEAL AND JITTERED SAMPLING RESULTS")
    print("========================================")

    print(f"Nominal period: {T_NOMINAL:.4f} seconds")
    print(f"Jitter bound: +/- {jitter_bound:.4f} seconds")
    print(f"Number of ideal samples: {len(ideal_times)}")
    print(f"Number of jittered samples: {len(jittered_times)}")

    print("\nJITTERED TIMING STATISTICS")

    print(f"Mean sample interval: {mean_interval:.6f} seconds")
    print(f"Standard deviation: {std_interval:.6f} seconds")
    print(f"Minimum interval: {min(intervals):.6f} seconds")
    print(f"Maximum interval: {max(intervals):.6f} seconds")

    # Generate continuous signal for plotting
    continuous_times = []
    continuous_values = []

    number_of_points = int(
        SIMULATION_DURATION / 0.01
    ) + 1

    for i in range(number_of_points):

        t = i * 0.01

        continuous_times.append(t)
        continuous_values.append(true_signal(t))

    # Calculate interval differences from nominal period
    interval_differences = [
        interval - T_NOMINAL
        for interval in intervals
    ]

    # Create two stacked plots
    fig, axes = plt.subplots(
        2,
        1,
        figsize=(13, 9)
    )

    # ----------------------------------------
    # TOP GRAPH: Signal and sample points
    # ----------------------------------------

    axes[0].plot(
        continuous_times,
        continuous_values,
        label="Continuous True Signal",
        color="black",
        linewidth=1.5
    )

    axes[0].scatter(
        ideal_times,
        ideal_values,
        label="Ideal Samples",
        marker="o",
        s=18
    )

    axes[0].scatter(
        jittered_times,
        jittered_values,
        label="Jittered Samples",
        marker="x",
        s=20
    )

    axes[0].axhline(
        y=THRESHOLD,
        linestyle="--",
        label="Controller Threshold"
    )

    axes[0].set_title(
        "Ideal and Jittered Sensor Sampling"
    )

    axes[0].set_xlabel("")
    axes[0].set_ylabel("Signal Value")

    axes[0].legend()
    axes[0].grid(True)

    # ----------------------------------------
    # BOTTOM GRAPH: Sampling interval variation
    # ----------------------------------------

    axes[1].plot(
        range(1, len(interval_differences) + 1),
        interval_differences,
        marker=".",
        markersize=4,
        linestyle="-",
        label="Interval - Nominal Period"
    )

    axes[1].axhline(
        y=0,
        linestyle="--",
        label="Zero Variation"
    )

    axes[1].set_title(
    "Sampling Interval Error by Cycle",
    pad=12
)

    axes[1].set_xlabel("Sampling Cycle")
    axes[1].set_ylabel("Interval Difference (seconds)")

    axes[1].legend()
    axes[1].grid(True)

    plt.tight_layout()

    # Save preliminary sampling graph
    plt.savefig(
        "results/figures/sampling_jitter_test.png",
        dpi=300
    )

    plt.show()

    print("\nSampling jitter test completed successfully!")
    print(
        "Graph saved in "
        "results/figures/sampling_jitter_test.png"
    )

# ============================================================
# 7. SIMULATE PROCESSING TIME
# ============================================================

def generate_processing_time(rng):

    # Decide whether this cycle experiences an overrun
    if rng.random() < OVERRUN_PROBABILITY:

        # Long computation time
        processing_time = rng.uniform(
            OVERRUN_PROCESSING_MIN,
            OVERRUN_PROCESSING_MAX
        )

    else:

        # Normal computation time
        processing_time = rng.uniform(
            NORMAL_PROCESSING_MIN,
            NORMAL_PROCESSING_MAX
        )

    return processing_time


# ============================================================
# 8. COMBINED SAMPLING AND PROCESSING OVERRUN SIMULATION
# ============================================================

def generate_overrun_samples(
    jitter_bound,
    overrun_probability=OVERRUN_PROBABILITY,
    seed=RANDOM_SEED
):

    rng = random.Random(seed)

    sample_times = []
    sample_values = []
    jitter_values = []
    processing_times = []
    overrun_flags = []

    # Running simulated clock
    clock = 0.0

    cycle = 0

    while clock < SIMULATION_DURATION:

        # Generate sampling jitter
        if cycle == 0:
            jitter = 0.0
        else:
            jitter = rng.uniform(
                -jitter_bound,
                jitter_bound
            )

        # Advance clock to the next sampling instant
        sample_time = clock + T_NOMINAL + jitter

        # Stop if the next sample is outside the simulation duration
        if sample_time > SIMULATION_DURATION:
            break

        # Read the simulated physical signal
        value = true_signal(sample_time)

        sample_times.append(sample_time)
        sample_values.append(value)
        jitter_values.append(jitter)

        # Generate computation time for this cycle
        if rng.random() < overrun_probability:

            processing_time = rng.uniform(
                OVERRUN_PROCESSING_MIN,
                OVERRUN_PROCESSING_MAX
            )

        else:

            processing_time = rng.uniform(
                NORMAL_PROCESSING_MIN,
                NORMAL_PROCESSING_MAX
            )

        processing_times.append(processing_time)

        # Check whether the computation exceeded its budget
        is_overrun = processing_time > T_NOMINAL

        overrun_flags.append(is_overrun)

        # Advance the clock by the computation time.
        # This delays the next sampling cycle.
        clock = sample_time + processing_time

        cycle += 1

    return (
        sample_times,
        sample_values,
        jitter_values,
        processing_times,
        overrun_flags
    )


# ============================================================
# 9. TEST PROCESSING-TIME OVERRUNS
# ============================================================

def test_processing_overruns():

    jitter_bound = 0.10 * T_NOMINAL

    (
        sample_times,
        sample_values,
        jitter_values,
        processing_times,
        overrun_flags
    ) = generate_overrun_samples(
        jitter_bound=jitter_bound,
        overrun_probability=OVERRUN_PROBABILITY
    )

    # Calculate actual inter-sample intervals
    intervals = []

    for i in range(1, len(sample_times)):

        intervals.append(
            sample_times[i] - sample_times[i - 1]
        )

    # Calculate overrun statistics
    total_cycles = len(processing_times)

    overrun_count = sum(overrun_flags)

    if total_cycles > 0:

        missed_percentage = (
            overrun_count / total_cycles
        ) * 100

        mean_processing_time = statistics.mean(
            processing_times
        )

        maximum_overrun = max(
            max(0.0, c - T_NOMINAL)
            for c in processing_times
        )

    else:

        missed_percentage = 0.0
        mean_processing_time = 0.0
        maximum_overrun = 0.0

    if len(intervals) > 1:

        mean_interval = statistics.mean(intervals)

        std_interval = statistics.stdev(intervals)

    elif len(intervals) == 1:

        mean_interval = intervals[0]
        std_interval = 0.0

    else:

        mean_interval = 0.0
        std_interval = 0.0

    print("\n========================================")
    print("PROCESSING-TIME OVERRUN RESULTS")
    print("========================================")

    print(f"Nominal period: {T_NOMINAL:.4f} seconds")

    print(
        f"Overrun probability: "
        f"{OVERRUN_PROBABILITY * 100:.1f}%"
    )

    print(f"Total sampling cycles: {total_cycles}")
    print(f"Overrun cycles: {overrun_count}")

    print(
        f"Actual overrun percentage: "
        f"{missed_percentage:.2f}%"
    )

    print(
        f"Mean processing time: "
        f"{mean_processing_time:.6f} seconds"
    )

    print(
        f"Maximum single-cycle overrun: "
        f"{maximum_overrun:.6f} seconds"
    )

    print(
        f"Mean actual sample interval: "
        f"{mean_interval:.6f} seconds"
    )

    print(
        f"Standard deviation of intervals: "
        f"{std_interval:.6f} seconds"
    )

    # ----------------------------------------
    # Plot processing time for each cycle
    # ----------------------------------------

    cycle_numbers = list(
        range(1, total_cycles + 1)
    )

    normal_cycles = [
        c if not is_overrun else 0
        for c, is_overrun in zip(
            processing_times,
            overrun_flags
        )
    ]

    overrun_cycles = [
        c if is_overrun else 0
        for c, is_overrun in zip(
            processing_times,
            overrun_flags
        )
    ]

    fig, ax = plt.subplots(figsize=(13, 5))

    ax.bar(
        cycle_numbers,
        normal_cycles,
        label="Normal Processing"
    )

    ax.bar(
        cycle_numbers,
        overrun_cycles,
        label="Processing Overrun"
    )

    ax.axhline(
        y=T_NOMINAL,
        linestyle="--",
        label="Nominal Period / Processing Budget"
    )

    ax.set_title(
        "Processing Time and Overruns Per Sampling Cycle"
    )

    ax.set_xlabel("Sampling Cycle")
    ax.set_ylabel("Processing Time (seconds)")

    ax.legend()
    ax.grid(True, axis="y")

    plt.tight_layout()

    plt.savefig(
        "results/figures/processing_overrun_test.png",
        dpi=300
    )

    plt.show()

    print("\nProcessing overrun test completed successfully!")

    print(
        "Graph saved in "
        "results/figures/processing_overrun_test.png"
    )

# ============================================================
# 10. THRESHOLD-BASED CONTROLLER
# ============================================================

def detect_actuations(sample_times, sample_values, threshold):

    actuation_times = []

    # Start from the second sample
    for i in range(1, len(sample_values)):

        previous_value = sample_values[i - 1]
        current_value = sample_values[i]

        # Detect an upward threshold crossing
        if previous_value < threshold and current_value >= threshold:

            # Record the time when the controller issues its command
            actuation_times.append(sample_times[i])

    return actuation_times


# ============================================================
# 11. COMPARE IDEAL AND REALISTIC CONTROLLERS
# ============================================================

def test_threshold_controller():

    # ----------------------------------------
    # IDEAL ZERO-JITTER BASELINE
    # ----------------------------------------

    ideal_times, ideal_values = generate_ideal_samples()

    ideal_actuations = detect_actuations(
        ideal_times,
        ideal_values,
        THRESHOLD
    )

    # ----------------------------------------
    # REALISTIC RUN WITH JITTER AND OVERRUNS
    # ----------------------------------------

    jitter_bound = 0.10 * T_NOMINAL

    (
        realistic_times,
        realistic_values,
        realistic_jitters,
        realistic_processing,
        realistic_overruns
    ) = generate_overrun_samples(
        jitter_bound=jitter_bound,
        overrun_probability=OVERRUN_PROBABILITY,
        seed=RANDOM_SEED
    )

    realistic_actuations = detect_actuations(
        realistic_times,
        realistic_values,
        THRESHOLD
    )

    # ----------------------------------------
    # MATCH THE CROSSINGS
    # ----------------------------------------

    matched_count = min(
        len(ideal_actuations),
        len(realistic_actuations)
    )

    actuation_delays = []

    for i in range(matched_count):

        delay = (
            realistic_actuations[i] -
            ideal_actuations[i]
        )

        actuation_delays.append(delay)

    # ----------------------------------------
    # DISPLAY RESULTS
    # ----------------------------------------

    print("\n========================================")
    print("THRESHOLD CONTROLLER RESULTS")
    print("========================================")

    print(f"Threshold value: {THRESHOLD}")

    print(
        f"Ideal actuation count: "
        f"{len(ideal_actuations)}"
    )

    print(
        f"Realistic actuation count: "
        f"{len(realistic_actuations)}"
    )

    print(
        f"Matched crossings: "
        f"{matched_count}"
    )

    if actuation_delays:

        mean_delay = statistics.mean(actuation_delays)

        maximum_delay = max(actuation_delays)

        print(
            f"Mean actuation delay: "
            f"{mean_delay:.6f} seconds"
        )

        print(
            f"Maximum actuation delay: "
            f"{maximum_delay:.6f} seconds"
        )

        print("\nINDIVIDUAL ACTUATION DELAYS")

        for i, delay in enumerate(actuation_delays, start=1):

            print(
                f"Crossing {i}: "
                f"{delay:.6f} seconds"
            )

    else:

        mean_delay = 0.0
        maximum_delay = 0.0

        print("No matching threshold crossings were found.")

    # ----------------------------------------
    # FIGURE 2: ACTUATION TIMELINE
    # ----------------------------------------

    fig, ax = plt.subplots(figsize=(13, 5))

    # Ideal controller actuation instants
    ax.scatter(
        ideal_actuations,
        [1] * len(ideal_actuations),
        marker="o",
        s=90,
        label="Ideal Controller"
    )

    # Realistic controller actuation instants
    ax.scatter(
        realistic_actuations,
        [0] * len(realistic_actuations),
        marker="x",
        s=100,
        label="Jittered and Overrun Controller"
    )

    # Connect matched crossings
    for i in range(matched_count):

        ax.plot(
            [
                ideal_actuations[i],
                realistic_actuations[i]
            ],
            [1, 0],
            linestyle="--",
            alpha=0.5
        )

    ax.set_yticks([0, 1])

    ax.set_yticklabels([
        "Realistic Controller",
        "Ideal Controller"
    ])

    ax.set_xlabel("Simulation Time (seconds)")

    ax.set_title(
        "Figure 2: Ideal and Realistic Controller Actuation Times"
    )

    ax.set_xlim(0, SIMULATION_DURATION)

    ax.set_ylim(-0.5, 1.5)

    ax.grid(True, axis="x")

    ax.legend(loc="upper right")

    # Display delay statistics on the graph
    annotation = (
        f"Mean actuation delay: {mean_delay:.4f} s\n"
        f"Maximum actuation delay: {maximum_delay:.4f} s"
    )

    ax.text(
        0.02,
        0.05,
        annotation,
        transform=ax.transAxes,
        verticalalignment="bottom",
        bbox=dict(
            boxstyle="round",
            facecolor="white",
            alpha=0.8
        )
    )

    plt.tight_layout()

    plt.savefig(
        "results/figures/controller_actuation_delay.png",
        dpi=300
    )

    plt.show()

    print("\nThreshold controller test completed successfully!")

    print(
        "Figure saved in "
        "results/figures/controller_actuation_delay.png"
    )

# MAIN PROGRAM
# ============================================================

# ============================================================
# MAIN PROGRAM
# ============================================================

# ============================================================
# MAIN PROGRAM
# ============================================================

# ============================================================
# MAIN PROGRAM
# ============================================================

if __name__ == "__main__":

    random.seed(RANDOM_SEED)

    # Part 1
    test_signal()

    # Part 2
    test_sampling_jitter()

    # Part 3
    test_processing_overruns()

    # Part 4
    test_threshold_controller()
