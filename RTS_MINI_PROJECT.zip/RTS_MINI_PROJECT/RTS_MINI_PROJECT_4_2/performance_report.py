
"""
Mini Project 4.2
Timing Compliance Reporting and Visualization

Generates:
1. Per-sensor timing compliance CSV.
2. Detailed scheduling events CSV.
3. Threshold alert CSV.
4. Sensor signal and sampling visualization.
5. On-time, late, and missed job comparison chart.
"""

import csv
from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt


def calculate_sensor_metrics(sensor):
    """Calculate timing compliance statistics for one sensor."""

    total = (
        sensor.on_time_samples
        + sensor.late_samples
        + sensor.missed_samples
    )

    if total > 0:
        on_time_percentage = (
            sensor.on_time_samples / total
        ) * 100.0
    else:
        on_time_percentage = 0.0

    if sensor.period_overruns:
        mean_overrun = (
            sum(sensor.period_overruns)
            / len(sensor.period_overruns)
        )

        maximum_overrun = max(sensor.period_overruns)

    else:
        mean_overrun = 0.0
        maximum_overrun = 0.0

    if sensor.alerts:
        mean_alert_latency = (
            sum(
                alert["detection_latency"]
                for alert in sensor.alerts
            )
            / len(sensor.alerts)
        )
    else:
        mean_alert_latency = 0.0

    return {
        "sensor": sensor.name,
        "sampling_period": sensor.period,
        "threshold": sensor.threshold,
        "required_samples": sensor.required_samples,
        "on_time": sensor.on_time_samples,
        "late": sensor.late_samples,
        "missed": sensor.missed_samples,
        "on_time_percentage": on_time_percentage,
        "mean_period_overrun": mean_overrun,
        "maximum_period_overrun": maximum_overrun,
        "alert_count": len(sensor.alerts),
        "mean_alert_latency": mean_alert_latency
    }


def save_compliance_csv(result, output_dir):
    """Save the per-sensor compliance report."""

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    filepath = output_dir / "timing_compliance.csv"

    fieldnames = [
        "sensor",
        "sampling_period",
        "threshold",
        "required_samples",
        "on_time",
        "late",
        "missed",
        "on_time_percentage",
        "mean_period_overrun",
        "maximum_period_overrun",
        "alert_count",
        "mean_alert_latency"
    ]

    with open(filepath, "w", newline="", encoding="utf-8") as file:

        writer = csv.DictWriter(
            file,
            fieldnames=fieldnames
        )

        writer.writeheader()

        for sensor in result["sensors"]:

            metrics = calculate_sensor_metrics(sensor)

            writer.writerow(metrics)

    return filepath


def save_events_csv(result, output_dir):
    """Save detailed job scheduling events."""

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    filepath = output_dir / "scheduling_events.csv"

    fieldnames = [
        "sensor",
        "job_number",
        "release",
        "deadline",
        "start",
        "completion",
        "processing_time",
        "overrun",
        "status"
    ]

    with open(filepath, "w", newline="", encoding="utf-8") as file:

        writer = csv.DictWriter(
            file,
            fieldnames=fieldnames
        )

        writer.writeheader()

        for event in result["events"]:
            writer.writerow(event)

    return filepath


def save_alerts_csv(result, output_dir):
    """Save true crossing and alert detection information."""

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    filepath = output_dir / "threshold_alerts.csv"

    fieldnames = [
        "sensor",
        "threshold",
        "true_crossing_time",
        "detection_time",
        "detection_latency",
        "measured_value"
    ]

    with open(filepath, "w", newline="", encoding="utf-8") as file:

        writer = csv.DictWriter(
            file,
            fieldnames=fieldnames
        )

        writer.writeheader()

        for alert in result["alerts"]:
            writer.writerow(alert)

    return filepath


def plot_sensor_signals(result, output_dir):
    """
    Plot each sensor's underlying signal, threshold,
    successful samples, late samples, and missed releases.
    """

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    sensors = result["sensors"]
    duration = result["duration"]

    fig, axes = plt.subplots(
        len(sensors),
        1,
        figsize=(12, 4 * len(sensors)),
        squeeze=False
    )

    for index, sensor in enumerate(sensors):

        ax = axes[index][0]

        # Generate continuous signal points for visualization.
        number_of_points = 1000

        times = [
            duration * i / (number_of_points - 1)
            for i in range(number_of_points)
        ]

        values = [
            sensor.signal_value(time_value)
            for time_value in times
        ]

        ax.plot(
            times,
            values,
            label="Underlying signal",
            linewidth=1.5
        )

        ax.axhline(
            sensor.threshold,
            linestyle="--",
            label="Alert threshold"
        )

        # Plot completed samples by timing status.
        for status, marker, label in [
            ("ON_TIME", "o", "On-time samples"),
            ("LATE", "x", "Late samples")
        ]:

            selected = [
                (time_value, value)
                for time_value, value, sample_status
                in zip(
                    sensor.sample_times,
                    sensor.sample_values,
                    sensor.sample_status
                )
                if sample_status == status
            ]

            if selected:

                ax.scatter(
                    [item[0] for item in selected],
                    [item[1] for item in selected],
                    marker=marker,
                    s=35,
                    label=label
                )

        # Plot missed releases at the underlying signal value.
        if sensor.missed_times:

            missed_values = [
                sensor.signal_value(time_value)
                for time_value in sensor.missed_times
            ]

            ax.scatter(
                sensor.missed_times,
                missed_values,
                marker="x",
                s=65,
                label="Missed jobs"
            )

        ax.set_title(
            f"{sensor.name} - Sampling Period: "
            f"{sensor.period:.2f}s"
        )

        ax.set_xlabel("Simulation time (seconds)")
        ax.set_ylabel("Sensor reading")
        ax.grid(True, alpha=0.3)
        ax.legend(loc="best")

    fig.suptitle(
        f"Environmental Signals and Sampling - "
        f"{result['policy']}",
        fontsize=14
    )

    fig.tight_layout()

    filepath = output_dir / "sensor_signals_and_samples.png"

    fig.savefig(filepath, dpi=150, bbox_inches="tight")
    plt.close(fig)

    return filepath


def plot_timing_compliance(result, output_dir):
    """Create a grouped bar chart of timing compliance."""

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    sensors = result["sensors"]

    names = [sensor.name for sensor in sensors]

    on_time = [
        sensor.on_time_samples
        for sensor in sensors
    ]

    late = [
        sensor.late_samples
        for sensor in sensors
    ]

    missed = [
        sensor.missed_samples
        for sensor in sensors
    ]

    positions = list(range(len(sensors)))
    width = 0.25

    fig, ax = plt.subplots(figsize=(11, 6))

    ax.bar(
        [position - width for position in positions],
        on_time,
        width,
        label="On time"
    )

    ax.bar(
        positions,
        late,
        width,
        label="Late"
    )

    ax.bar(
        [position + width for position in positions],
        missed,
        width,
        label="Missed"
    )

    ax.set_title(
        f"Timing Compliance by Sensor - {result['policy']}"
    )

    ax.set_xlabel("Environmental sensor")
    ax.set_ylabel("Number of jobs")

    ax.set_xticks(positions)
    ax.set_xticklabels(names)

    ax.legend()
    ax.grid(axis="y", alpha=0.3)

    fig.tight_layout()

    filepath = output_dir / "timing_compliance_chart.png"

    fig.savefig(filepath, dpi=150, bbox_inches="tight")
    plt.close(fig)

    return filepath


def print_compliance_report(result):
    """Print a readable timing compliance report."""

    print("\n" + "=" * 105)
    print("PER-SENSOR TIMING COMPLIANCE REPORT")
    print("=" * 105)

    print(
        f"{'Sensor':<18}"
        f"{'Required':>10}"
        f"{'On time':>10}"
        f"{'Late':>10}"
        f"{'Missed':>10}"
        f"{'Mean overrun':>17}"
        f"{'Max overrun':>17}"
    )

    print("-" * 105)

    for sensor in result["sensors"]:

        metrics = calculate_sensor_metrics(sensor)

        print(
            f"{sensor.name:<18}"
            f"{metrics['required_samples']:>10}"
            f"{metrics['on_time']:>10}"
            f"{metrics['late']:>10}"
            f"{metrics['missed']:>10}"
            f"{metrics['mean_period_overrun']:>15.4f}s"
            f"{metrics['maximum_period_overrun']:>15.4f}s"
        )

    print("-" * 105)

    print(
        f"Total threshold alerts: {len(result['alerts'])}"
    )


def generate_all_reports(result, output_dir):
    """Generate all CSV reports and figures."""

    output_dir = Path(output_dir)

    report_dir = output_dir / "reports"
    figure_dir = output_dir / "figures"

    report_dir.mkdir(parents=True, exist_ok=True)
    figure_dir.mkdir(parents=True, exist_ok=True)

    print_compliance_report(result)

    compliance_file = save_compliance_csv(
        result,
        report_dir
    )

    events_file = save_events_csv(
        result,
        report_dir
    )

    alerts_file = save_alerts_csv(
        result,
        report_dir
    )

    signal_figure = plot_sensor_signals(
        result,
        figure_dir
    )

    compliance_figure = plot_timing_compliance(
        result,
        figure_dir
    )

    print("\nREPORT FILES GENERATED")
    print("-" * 60)

    for filepath in [
        compliance_file,
        events_file,
        alerts_file,
        signal_figure,
        compliance_figure
    ]:
        print(filepath)

    return {
        "compliance_csv": compliance_file,
        "events_csv": events_file,
        "alerts_csv": alerts_file,
        "signal_figure": signal_figure,
        "compliance_figure": compliance_figure
    }
