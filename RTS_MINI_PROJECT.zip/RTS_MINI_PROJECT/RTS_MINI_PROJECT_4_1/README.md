
# Real-Time Systems – Mini Project 4.1

## Project Title
Simulating Sampling Jitter and Processing Overruns in an Embedded Sensing-and-Control Loop

## Objective
To develop a Python simulation that demonstrates how sampling jitter and processing overruns affect an embedded sensing-and-control loop.

## Technologies
- Python 3.10+
- Matplotlib
- Random module
- Statistics module

## Main Features
- Simulated sensor signal
- Ideal fixed-period sampling
- Sampling jitter simulation
- Processing overrun simulation
- Threshold-based controller
- Timing statistics
- Actuation delay analysis
- Graphical visualization

## Project Structure
- rt_sampling_sim.py: Main simulation
- results/figures/: Generated graphs
- reports/: Project reports

## How to Run
python rt_sampling_sim.py

## Expected Output
- Timing statistics
- Sampling and signal visualization
- Controller actuation comparison
- Experimental results
