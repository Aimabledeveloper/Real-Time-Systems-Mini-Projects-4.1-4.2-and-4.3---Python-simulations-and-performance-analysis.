
"""
Mini Project 4.3
Hybrid Edge-Cloud Policy

Every decision is processed at the edge first.
A configurable percentage of difficult decisions
is then sent to the cloud for additional processing.
"""

import random
from typing import List

from edge_cloud_models import (
    EdgeCloudConfig,
    simulate_edge_latency,
    simulate_cloud_latency
)

from simulation import (
    SimulationEvent,
    create_event
)


def run_hybrid_simulation(
    number_of_events: int = 10000,
    sampling_period_ms: float = 50.0,
    congestion_level: float = 0.0,
    hard_decision_probability: float = 0.15,
    seed: int = 42,
    config: EdgeCloudConfig = None
) -> List[SimulationEvent]:
    """
    Simulate an edge-first hybrid processing policy.

    All decisions are processed at the edge.
    Difficult decisions are forwarded to the cloud.

    Total latency for a cloud fallback decision includes:
        Edge processing + Cloud upload +
        Cloud processing + Cloud download +
        Congestion delay.
    """

    if number_of_events <= 0:
        raise ValueError("Number of events must be positive.")

    if sampling_period_ms <= 0:
        raise ValueError("Sampling period must be positive.")

    if not 0.0 <= congestion_level <= 1.0:
        raise ValueError("Congestion level must be between 0 and 1.")

    if not 0.0 <= hard_decision_probability <= 1.0:
        raise ValueError(
            "Hard decision probability must be between 0 and 1."
        )

    if config is None:
        config = EdgeCloudConfig()

    config.validate()

    rng = random.Random(seed)

    events = []

    for event_id in range(1, number_of_events + 1):

        release_time = (event_id - 1) * sampling_period_ms

        # First attempt: local edge processing
        edge_result = simulate_edge_latency(
            rng,
            config
        )

        # Determine whether this is a difficult decision
        is_difficult = (
            rng.random() < hard_decision_probability
        )

        if is_difficult:

            # Fallback: send the difficult decision to cloud
            cloud_result = simulate_cloud_latency(
                rng,
                config,
                congestion_level
            )

            total_latency = (
                edge_result.total_latency
                + cloud_result.total_latency
            )

            combined_processing = (
                edge_result.processing_latency
                + cloud_result.processing_latency
            )

            # Combine the edge and cloud measurements
            from edge_cloud_models import LatencyResult

            hybrid_result = LatencyResult(
                total_latency=total_latency,
                processing_latency=combined_processing,
                upload_latency=cloud_result.upload_latency,
                download_latency=cloud_result.download_latency,
                congestion_delay=cloud_result.congestion_delay,
                execution_mode="HYBRID"
            )

        else:

            # Easy decision completed entirely at the edge
            from edge_cloud_models import LatencyResult

            hybrid_result = LatencyResult(
                total_latency=edge_result.total_latency,
                processing_latency=edge_result.processing_latency,
                execution_mode="HYBRID"
            )

        events.append(
            create_event(
                event_id,
                release_time,
                "HYBRID",
                hybrid_result,
                config.deadline_ms
            )
        )

    return events


if __name__ == "__main__":

    configuration = EdgeCloudConfig()

    results = run_hybrid_simulation(
        number_of_events=1000,
        sampling_period_ms=50.0,
        congestion_level=0.5,
        hard_decision_probability=0.15,
        seed=42,
        config=configuration
    )

    total = len(results)

    met = sum(event.deadline_met for event in results)

    missed = total - met

    mean_latency = (
        sum(event.total_latency_ms for event in results) / total
    )

    fallback_count = sum(
    event.upload_latency_ms > 0
    for event in results
)

    print("\n" + "=" * 65)
    print("HYBRID EDGE-CLOUD SIMULATION")
    print("=" * 65)

    print(f"Total decisions       : {total}")
    print(f"Cloud fallback events : {fallback_count}")
    print(f"Edge-only decisions   : {total - fallback_count}")
    print(f"Deadlines met         : {met}")
    print(f"Deadlines missed      : {missed}")
    print(f"Deadline compliance   : {met / total * 100:.2f}%")
    print(f"Mean latency          : {mean_latency:.2f} ms")

    print("=" * 65)
