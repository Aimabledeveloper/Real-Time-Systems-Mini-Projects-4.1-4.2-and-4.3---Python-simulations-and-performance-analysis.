
# ============================================================
# REAL-TIME SYSTEMS - MINI PROJECT 4.1
# PART 6: STATISTICAL ANALYSIS
# Analysis of Five Experimental Runs and 95% Confidence Intervals
# ============================================================

import csv
import math
import statistics
from pathlib import Path

import matplotlib.pyplot as plt


# ============================================================
# 1. CONFIGURATION
# ============================================================

INPUT_FILE = Path("results/part5/experimental_results.csv")

OUTPUT_DIR = Path("results/part6")

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

NUMBER_OF_RUNS = 5

# Student's t critical value:
# 95% confidence interval, 4 degrees of freedom
T_CRITICAL = 2.776445

METRICS = [
    "cycles",
    "overrun_cycles",
    "overrun_rate_pct",
    "mean_interval_s",
    "std_interval_s",
    "minimum_interval_s",
    "maximum_interval_s",
    "mean_processing_s",
    "max_overrun_s",
    "ideal_crossings",
    "realistic_crossings",
    "matched_crossings",
    "mean_delay_s",
    "std_delay_s",
    "minimum_delay_s",
    "maximum_delay_s",
    "maximum_absolute_delay_s"
]


# ============================================================
# 2. LOAD EXPERIMENTAL DATA
# ============================================================

def load_experimental_data():

    if not INPUT_FILE.exists():

        raise FileNotFoundError(
            f"Experimental data not found: {INPUT_FILE}\n"
            "Run part5_experiments.py first."
        )

    with open(
        INPUT_FILE,
        "r",
        newline="",
        encoding="utf-8"
    ) as file:

        reader = csv.DictReader(file)

        data = list(reader)

    if not data:

        raise ValueError("The experimental CSV file is empty.")

    print("\nEXPERIMENTAL DATA LOADED")

    print(f"Source: {INPUT_FILE}")

    print(f"Total experimental records: {len(data)}")

    return data


# ============================================================
# 3. CALCULATE STATISTICAL MEASUREMENTS
# ============================================================

def calculate_statistics(values):

    if not values:

        return {
            "count": 0,
            "mean": None,
            "std": None,
            "minimum": None,
            "maximum": None,
            "ci_lower": None,
            "ci_upper": None
        }

    mean_value = statistics.mean(values)

    std_value = (
        statistics.stdev(values)
        if len(values) > 1
        else 0.0
    )

    if len(values) > 1:

        margin = (
            T_CRITICAL
            * std_value
            / math.sqrt(len(values))
        )

    else:

        margin = 0.0

    return {
        "count": len(values),
        "mean": mean_value,
        "std": std_value,
        "minimum": min(values),
        "maximum": max(values),
        "ci_lower": mean_value - margin,
        "ci_upper": mean_value + margin
    }


# ============================================================
# 4. GROUP EXPERIMENTAL CONFIGURATIONS
# ============================================================

def group_experiments(data):

    groups = {}

    for row in data:

        key = (
            row["experiment"],
            row["condition"]
        )

        groups.setdefault(key, []).append(row)

    print("\nEXPERIMENTAL CONFIGURATIONS")

    for experiment, condition in groups:

        print(f"{experiment}: {condition}")

    return groups


# ============================================================
# 5. GENERATE STATISTICAL SUMMARY
# ============================================================

def generate_summary(groups):

    summary_rows = []

    for (experiment, condition), records in groups.items():

        result = {
            "experiment": experiment,
            "condition": condition,
            "number_of_runs": len(records)
        }

        for metric in METRICS:

            values = []

            for record in records:

                raw_value = record.get(metric, "")

                if raw_value not in ("", None):

                    values.append(float(raw_value))

            stats = calculate_statistics(values)

            result[f"{metric}_mean"] = stats["mean"]

            result[f"{metric}_std"] = stats["std"]

            result[f"{metric}_minimum"] = stats["minimum"]

            result[f"{metric}_maximum"] = stats["maximum"]

            result[f"{metric}_ci_lower"] = stats["ci_lower"]

            result[f"{metric}_ci_upper"] = stats["ci_upper"]

        summary_rows.append(result)

    return summary_rows


# ============================================================
# 6. SAVE STATISTICAL SUMMARY
# ============================================================

def save_summary(summary_rows):

    output_file = OUTPUT_DIR / "statistical_summary.csv"

    if not summary_rows:

        raise ValueError("No statistical summary available.")

    fieldnames = list(summary_rows[0].keys())

    with open(
        output_file,
        "w",
        newline="",
        encoding="utf-8"
    ) as file:

        writer = csv.DictWriter(
            file,
            fieldnames=fieldnames
        )

        writer.writeheader()

        writer.writerows(summary_rows)

    print("\nSTATISTICAL SUMMARY SAVED")

    print(output_file)


# ============================================================
# 7. DISPLAY JITTER STATISTICS
# ============================================================

def display_jitter_results(summary_rows):

    print("\n" + "=" * 75)

    print("PART 6A: SAMPLING JITTER STATISTICAL ANALYSIS")

    print("=" * 75)

    for row in summary_rows:

        if row["experiment"] != "Sampling Jitter":

            continue

        print(f"\nConfiguration: {row['condition']}")

        print(
            f"Mean sampling interval: "
            f"{row['mean_interval_s_mean']:.6f} seconds"
        )

        print(
            f"Standard deviation: "
            f"{row['std_interval_s_mean']:.6f} seconds"
        )

        print(
            f"95% CI of mean interval: "
            f"[{row['mean_interval_s_ci_lower']:.6f}, "
            f"{row['mean_interval_s_ci_upper']:.6f}]"
        )


# ============================================================
# 8. DISPLAY OVERRUN STATISTICS
# ============================================================

def display_overrun_results(summary_rows):

    print("\n" + "=" * 75)

    print("PART 6B: PROCESSING OVERRUN STATISTICAL ANALYSIS")

    print("=" * 75)

    for row in summary_rows:

        if row["experiment"] != "Processing Overrun":

            continue

        print(f"\nConfiguration: {row['condition']}")

        print(
            f"Mean overrun rate: "
            f"{row['overrun_rate_pct_mean']:.2f}%"
        )

        print(
            f"Mean processing time: "
            f"{row['mean_processing_s_mean']:.6f} seconds"
        )

        print(
            f"Mean sampling interval: "
            f"{row['mean_interval_s_mean']:.6f} seconds"
        )

        print(
            f"95% CI of sampling interval: "
            f"[{row['mean_interval_s_ci_lower']:.6f}, "
            f"{row['mean_interval_s_ci_upper']:.6f}]"
        )


# ============================================================
# 9. DISPLAY CONTROLLER STATISTICS
# ============================================================

def display_controller_results(summary_rows):

    print("\n" + "=" * 75)

    print("PART 6C: CONTROLLER PERFORMANCE STATISTICAL ANALYSIS")

    print("=" * 75)

    for row in summary_rows:

        if row["experiment"] != "Controller Performance":

            continue

        print(f"\nConfiguration: {row['condition']}")

        print(
            f"Mean actuation delay: "
            f"{row['mean_delay_s_mean']:.6f} seconds"
        )

        print(
            f"Standard deviation between run-level delays: "
            f"{row['mean_delay_s_std']:.6f} seconds"
        )

        print(
            f"95% CI of mean actuation delay: "
            f"[{row['mean_delay_s_ci_lower']:.6f}, "
            f"{row['mean_delay_s_ci_upper']:.6f}]"
        )

        print(
            f"Mean maximum absolute delay: "
            f"{row['maximum_absolute_delay_s_mean']:.6f} seconds"
        )


# ============================================================
# 10. PLOT CONTROLLER CONFIDENCE INTERVALS
# ============================================================

def plot_controller_confidence(summary_rows):

    controller_rows = [
        row for row in summary_rows
        if row["experiment"] == "Controller Performance"
        and row["mean_delay_s_mean"] is not None
    ]

    if not controller_rows:

        print("No controller statistics available for plotting.")

        return

    labels = [
        row["condition"].replace(", ", "\n")
        for row in controller_rows
    ]

    means = [
        row["mean_delay_s_mean"]
        for row in controller_rows
    ]

    lower_errors = [
        row["mean_delay_s_mean"] - row["mean_delay_s_ci_lower"]
        for row in controller_rows
    ]

    upper_errors = [
        row["mean_delay_s_ci_upper"] - row["mean_delay_s_mean"]
        for row in controller_rows
    ]

    fig, ax = plt.subplots(figsize=(14, 7))

    ax.errorbar(
        range(len(means)),
        means,
        yerr=[lower_errors, upper_errors],
        fmt="o",
        capsize=5,
        label="Mean delay with 95% confidence interval"
    )

    ax.axhline(
        y=0,
        linestyle="--",
        label="Zero delay"
    )

    ax.set_xticks(range(len(labels)))

    ax.set_xticklabels(
        labels,
        rotation=30,
        ha="right"
    )

    ax.set_title(
        "Controller Actuation Delay with 95% Confidence Intervals"
    )

    ax.set_xlabel("Experimental Configuration")

    ax.set_ylabel("Mean Actuation Delay (seconds)")

    ax.grid(True)

    ax.legend()

    plt.tight_layout()

    output_file = OUTPUT_DIR / "controller_confidence_intervals.png"

    fig.savefig(output_file, dpi=300)

    plt.close(fig)

    print("\nCONFIDENCE INTERVAL GRAPH SAVED")

    print(output_file)


# ============================================================
# 11. MAIN PROGRAM
# ============================================================

if __name__ == "__main__":

    print("\n" + "=" * 75)

    print("REAL-TIME SYSTEMS MINI PROJECT 4.1")

    print("PART 6: STATISTICAL ANALYSIS")

    print("=" * 75)

    # Load Part 5 experimental results
    data = load_experimental_data()

    # Organize experimental configurations
    groups = group_experiments(data)

    # Calculate statistics
    summary_rows = generate_summary(groups)

    # Save summary
    save_summary(summary_rows)

    # Display experimental analysis
    display_jitter_results(summary_rows)

    display_overrun_results(summary_rows)

    display_controller_results(summary_rows)

    # Generate confidence interval graph
    plot_controller_confidence(summary_rows)

    print("\n" + "=" * 75)

    print("PART 6 COMPLETED SUCCESSFULLY!")

    print("=" * 75)

    print(f"Statistical results directory: {OUTPUT_DIR}")
