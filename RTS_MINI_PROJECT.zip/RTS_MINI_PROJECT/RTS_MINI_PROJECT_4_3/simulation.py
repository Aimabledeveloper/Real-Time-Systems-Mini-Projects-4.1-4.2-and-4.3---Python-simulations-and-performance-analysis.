
"""
Mini Project 4.3
Simulation Engine

Generates fixed-rate sensor events and evaluates
edge and cloud decision-processing latency.
"""

from dataclasses import dataclass, asdict
from typing import List
import random

from edge_cloud_models import (
    EdgeCloudConfig,
    LatencyResult,
    simulate_edge_latency,
    simulate_cloud_latency
)


@dataclass
class SimulationEvent:
    """One sensor decision event."""

    event_id: int
    release_time_ms: float
    execution_mode: str
    total_latency_ms: float
    deadline_ms: float
    deadline_met: bool
    processing_latency_ms: float
    upload_latency_ms: float
    download_latency_ms: float
    congestion_delay_ms: float


def create_event(
    event_id: int,
    release_time_ms: float,
    mode: str,
    result: LatencyResult,
    deadline_ms: float
) -> SimulationEvent:

    return SimulationEvent(
        event_id=event_id,
        release_time_ms=release_time_ms,
        execution_mode=mode,
        total_latency_ms=result.total_latency,
        deadline_ms=deadline_ms,
        deadline_met=result.deadline_met(deadline_ms),
        processing_latency_ms=result.processing_latency,
        upload_latency_ms=result.upload_latency,
        download_latency_ms=result.download_latency,
        congestion_delay_ms=result.congestion_delay
    )


def run_simulation(
    number_of_events: int = 10000,
    sampling_period_ms: float = 50.0,
    congestion_level: float = 0.0,
    seed: int = 42,
    config: EdgeCloudConfig = None
) -> List[SimulationEvent]:
    """
    Run edge and cloud simulations using the same
    sensor event release times.

    Each event is independently evaluated by both
    processing architectures.
    """

    if number_of_events <= 0:
        raise ValueError("Number of events must be positive.")

    if sampling_period_ms <= 0:
        raise ValueError("Sampling period must be positive.")

    if not 0.0 <= congestion_level <= 1.0:
        raise ValueError("Congestion level must be between 0 and 1.")

    if config is None:
        config = EdgeCloudConfig()

    config.validate()

    rng = random.Random(seed)

    events = []

    for event_id in range(1, number_of_events + 1):

        release_time = (event_id - 1) * sampling_period_ms

        # Edge decision
        edge_result = simulate_edge_latency(
            rng,
            config
        )

        events.append(
            create_event(
                event_id,
                release_time,
                "EDGE",
                edge_result,
                config.deadline_ms
            )
        )

        # Cloud decision
        cloud_result = simulate_cloud_latency(
            rng,
            config,
            congestion_level
        )

        events.append(
            create_event(
                event_id,
                release_time,
                "CLOUD",
                cloud_result,
                config.deadline_ms
            )
        )

    return events


def summarize_results(events: List[SimulationEvent]) -> dict:
    """Calculate basic deadline and latency statistics."""

    summary = {}

    for mode in ("EDGE", "CLOUD"):

        selected = [
            event for event in events
            if event.execution_mode == mode
        ]

        if not selected:
            continue

        latencies = [
            event.total_latency_ms
            for event in selected
        ]

        total = len(selected)

        met = sum(
            event.deadline_met
            for event in selected
        )

        summary[mode] = {
            "total_events": total,
            "deadline_met": met,
            "deadline_missed": total - met,
            "compliance_percentage": (met / total) * 100,
            "mean_latency_ms": sum(latencies) / total,
            "minimum_latency_ms": min(latencies),
            "maximum_latency_ms": max(latencies)
        }

    return summary


def print_summary(summary: dict):
    """Print a readable simulation summary."""

    print("\n" + "=" * 75)
    print("EDGE-VERSUS-CLOUD SIMULATION SUMMARY")
    print("=" * 75)

    print(
        f"{'Mode':<12}"
        f"{'Events':>10}"
        f"{'Met':>10}"
        f"{'Missed':>10}"
        f"{'Compliance':>15}"
        f"{'Mean (ms)':>14}"
    )

    print("-" * 75)

    for mode, data in summary.items():

        print(
            f"{mode:<12}"
            f"{data['total_events']:>10}"
            f"{data['deadline_met']:>10}"
            f"{data['deadline_missed']:>10}"
            f"{data['compliance_percentage']:>14.2f}%"
            f"{data['mean_latency_ms']:>13.2f}"
        )

    print("=" * 75)


if __name__ == "__main__":

    configuration = EdgeCloudConfig()

    results = run_simulation(
        number_of_events=1000,
        sampling_period_ms=50.0,
        congestion_level=0.5,
        seed=42,
        config=configuration
    )

    summary = summarize_results(results)

    print_summary(summary)
