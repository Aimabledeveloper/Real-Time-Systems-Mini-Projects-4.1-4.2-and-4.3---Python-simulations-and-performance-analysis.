
"""
Mini Project 4.3
Edge-versus-Cloud Latency Simulator

This module defines the edge and cloud processing models.
All latency values are measured in milliseconds.
"""

from dataclasses import dataclass
import random


@dataclass
class LatencyResult:
    """Stores the latency details of one decision."""

    total_latency: float
    processing_latency: float
    upload_latency: float = 0.0
    download_latency: float = 0.0
    congestion_delay: float = 0.0
    execution_mode: str = "UNKNOWN"

    def deadline_met(self, deadline_ms: float) -> bool:
        """Check whether the decision completed before its deadline."""
        return self.total_latency <= deadline_ms


@dataclass
class EdgeCloudConfig:
    """Configurable simulation parameters."""

    deadline_ms: float = 100.0

    # Edge processing parameters
    edge_mean_ms: float = 18.0
    edge_std_ms: float = 3.0

    # Cloud processing parameters
    cloud_upload_min_ms: float = 15.0
    cloud_upload_max_ms: float = 25.0

    cloud_processing_min_ms: float = 20.0
    cloud_processing_max_ms: float = 35.0

    cloud_download_min_ms: float = 15.0
    cloud_download_max_ms: float = 25.0

    # Congestion parameters
    congestion_probability_base: float = 0.02
    congestion_probability_max: float = 0.40

    congestion_delay_min_ms: float = 80.0
    congestion_delay_max_ms: float = 220.0

    def validate(self):
        """Validate configuration values."""

        if self.deadline_ms <= 0:
            raise ValueError("Deadline must be greater than zero.")

        if self.edge_mean_ms <= 0 or self.edge_std_ms < 0:
            raise ValueError("Invalid edge processing parameters.")

        if not 0 <= self.congestion_probability_base <= 1:
            raise ValueError("Base congestion probability must be between 0 and 1.")

        if not 0 <= self.congestion_probability_max <= 1:
            raise ValueError("Maximum congestion probability must be between 0 and 1.")

        if self.congestion_probability_max < self.congestion_probability_base:
            raise ValueError("Maximum congestion probability cannot be below the base.")

        if self.congestion_delay_min_ms < 0:
            raise ValueError("Congestion delay cannot be negative.")


def simulate_edge_latency(
    rng: random.Random,
    config: EdgeCloudConfig
) -> LatencyResult:
    """
    Simulate local edge processing.

    Edge processing has low latency and low variation.
    """

    config.validate()

    processing_time = rng.gauss(
        config.edge_mean_ms,
        config.edge_std_ms
    )

    processing_time = max(1.0, processing_time)

    return LatencyResult(
        total_latency=processing_time,
        processing_latency=processing_time,
        execution_mode="EDGE"
    )


def simulate_cloud_latency(
    rng: random.Random,
    config: EdgeCloudConfig,
    congestion_level: float = 0.0
) -> LatencyResult:
    """
    Simulate cloud processing.

    Total latency includes:
    1. Uploading sensor data.
    2. Remote cloud computation.
    3. Downloading the decision.
    4. Additional delay during network congestion.

    congestion_level must be between 0.0 and 1.0.
    """

    config.validate()

    if not 0.0 <= congestion_level <= 1.0:
        raise ValueError(
            "Congestion level must be between 0.0 and 1.0."
        )

    upload_time = rng.uniform(
        config.cloud_upload_min_ms,
        config.cloud_upload_max_ms
    )

    processing_time = rng.uniform(
        config.cloud_processing_min_ms,
        config.cloud_processing_max_ms
    )

    download_time = rng.uniform(
        config.cloud_download_min_ms,
        config.cloud_download_max_ms
    )

    congestion_probability = (
        config.congestion_probability_base
        + congestion_level * (
            config.congestion_probability_max
            - config.congestion_probability_base
        )
    )

    congestion_delay = 0.0

    if rng.random() < congestion_probability:
        congestion_delay = rng.uniform(
            config.congestion_delay_min_ms,
            config.congestion_delay_max_ms
        )

    total_latency = (
        upload_time
        + processing_time
        + download_time
        + congestion_delay
    )

    return LatencyResult(
        total_latency=total_latency,
        processing_latency=processing_time,
        upload_latency=upload_time,
        download_latency=download_time,
        congestion_delay=congestion_delay,
        execution_mode="CLOUD"
    )
