
"""
Mini Project 4.2
Multi-Rate Environmental Monitoring Pipeline

Main experiment runner.

Experiments:
1. Three sensors + EDF
2. Three sensors + Fixed Priority
3. Four sensors + EDF
4. Four sensors + Fixed Priority

Generates individual reports and figures for each experiment
and a combined comparison CSV.
"""

import csv
from pathlib import Path

from sensors import (
    create_default_sensors,
    create_four_sensor_load
)

from scheduler import MultiRateScheduler

from performance_report import (
    generate_all_reports,
    calculate_sensor_metrics
)


# ---------------------------------------------------------
# EXPERIMENT CONFIGURATION
# ---------------------------------------------------------

SIMULATION_DURATION = 60.0
RANDOM_SEED = 42

OUTPUT_DIRECTORY = Path("results")


def run_experiment(
    configuration_name,
    sensor_factory,
    policy
):
    """Run one scheduling experiment."""

    print("\n\n")
    print("#" * 75)
    print(f"EXPERIMENT: {configuration_name}")
    print("#" * 75)

    sensors = sensor_factory()

    scheduler = MultiRateScheduler(
        sensors=sensors,
        policy=policy,
        duration=SIMULATION_DURATION,
        seed=RANDOM_SEED
    )

    result = scheduler.run()

    # Generate CSV reports and figures.
    output_directory = (
        OUTPUT_DIRECTORY / configuration_name
    )

    generated_files = generate_all_reports(
        result,
        output_directory
    )

    # Display alert information.
    scheduler.alert_system.print_alert_summary(sensors)

    return {
        "configuration": configuration_name,
        "policy": policy,
        "sensor_count": len(sensors),
        "result": result,
        "generated_files": generated_files
    }


def save_combined_comparison(experiments):
    """Save all experiment results into one comparison CSV."""

    filepath = OUTPUT_DIRECTORY / "comparison_summary.csv"

    filepath.parent.mkdir(
        parents=True,
        exist_ok=True
    )

    
    fieldnames = [
        "configuration",
        "policy",
        "sensor",
        "sampling_period",
        "threshold",
        "required_samples",
        "on_time",
        "late",
        "missed",
        "on_time_percentage",
        "mean_period_overrun",
        "maximum_period_overrun",
        "alert_count",
        "mean_alert_latency"
    ]


    with open(
        filepath,
        "w",
        newline="",
        encoding="utf-8"
    ) as file:

        writer = csv.DictWriter(
            file,
            fieldnames=fieldnames
        )

        writer.writeheader()

        for experiment in experiments:

            for sensor in experiment["result"]["sensors"]:

                metrics = calculate_sensor_metrics(sensor)

                row = {
                    "configuration": experiment["configuration"],
                    "policy": experiment["policy"],
                    **metrics
                }

                writer.writerow(row)

    return filepath


def print_overall_comparison(experiments):
    """Print a summary comparing the four experiments."""

    print("\n\n")
    print("=" * 105)
    print("OVERALL EXPERIMENT COMPARISON")
    print("=" * 105)

    print(
        f"{'Configuration':<25}"
        f"{'Policy':<17}"
        f"{'Required':>12}"
        f"{'On time':>12}"
        f"{'Late':>10}"
        f"{'Missed':>10}"
        f"{'Compliance':>15}"
    )

    print("-" * 105)

    for experiment in experiments:

        sensors = experiment["result"]["sensors"]

        required = sum(
            sensor.required_samples for sensor in sensors
        )

        on_time = sum(
            sensor.on_time_samples for sensor in sensors
        )

        late = sum(
            sensor.late_samples for sensor in sensors
        )

        missed = sum(
            sensor.missed_samples for sensor in sensors
        )

        if required:
            compliance = (on_time / required) * 100.0
        else:
            compliance = 0.0

        print(
            f"{experiment['configuration']:<25}"
            f"{experiment['policy']:<17}"
            f"{required:>12}"
            f"{on_time:>12}"
            f"{late:>10}"
            f"{missed:>10}"
            f"{compliance:>14.2f}%"
        )

    print("=" * 105)


def main():
    """Execute all four experiments."""

    print("=" * 75)
    print("REAL-TIME SYSTEMS - MINI PROJECT 4.2")
    print("MULTI-RATE ENVIRONMENTAL MONITORING PIPELINE")
    print("=" * 75)

    print(f"Simulation duration: {SIMULATION_DURATION} seconds")
    print(f"Random seed: {RANDOM_SEED}")

    experiments = []

    experiment_definitions = [
        (
            "three_sensors_edf",
            create_default_sensors,
            "EDF"
        ),
        (
            "three_sensors_fixed_priority",
            create_default_sensors,
            "FIXED_PRIORITY"
        ),
        (
            "four_sensors_edf",
            create_four_sensor_load,
            "EDF"
        ),
        (
            "four_sensors_fixed_priority",
            create_four_sensor_load,
            "FIXED_PRIORITY"
        )
    ]

    for name, sensor_factory, policy in experiment_definitions:

        experiment = run_experiment(
            configuration_name=name,
            sensor_factory=sensor_factory,
            policy=policy
        )

        experiments.append(experiment)

    # Create combined comparison.
    print_overall_comparison(experiments)

    comparison_file = save_combined_comparison(
        experiments
    )

    print("\nALL EXPERIMENTS COMPLETED")
    print("-" * 75)

    print(f"Combined comparison: {comparison_file}")

    print("\nIndividual experiment folders:")

    for experiment in experiments:
        print(
            OUTPUT_DIRECTORY
            / experiment["configuration"]
        )

    print("\nMini Project 4.2 simulation finished successfully.")


if __name__ == "__main__":
    main()
