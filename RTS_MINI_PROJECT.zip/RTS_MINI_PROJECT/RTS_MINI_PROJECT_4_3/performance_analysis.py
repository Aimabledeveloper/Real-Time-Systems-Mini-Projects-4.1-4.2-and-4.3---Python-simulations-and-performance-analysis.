
"""
Mini Project 4.3
Performance Analysis

Calculates latency statistics and deadline compliance
for Edge, Cloud, and Hybrid computing architectures.
"""

import csv
import os
from typing import List

from simulation import (
    SimulationEvent,
    run_simulation
)

from hybrid_policy import run_hybrid_simulation

from edge_cloud_models import EdgeCloudConfig


def calculate_percentile(values: List[float], percentile: float) -> float:
    """Calculate a percentile using linear interpolation."""

    if not values:
        return 0.0

    if not 0 <= percentile <= 100:
        raise ValueError("Percentile must be between 0 and 100.")

    sorted_values = sorted(values)

    if len(sorted_values) == 1:
        return sorted_values[0]

    position = (len(sorted_values) - 1) * percentile / 100

    lower_index = int(position)
    upper_index = min(lower_index + 1, len(sorted_values) - 1)

    fraction = position - lower_index

    return (
        sorted_values[lower_index] * (1 - fraction)
        + sorted_values[upper_index] * fraction
    )


def analyze_events(
    events: List[SimulationEvent],
    architecture: str
) -> dict:
    """Calculate performance metrics for one architecture."""

    if not events:
        raise ValueError("Cannot analyze an empty event list.")

    latencies = [
        event.total_latency_ms
        for event in events
    ]

    total_events = len(events)

    deadlines_met = sum(
        event.deadline_met
        for event in events
    )

    deadlines_missed = total_events - deadlines_met

    return {
        "architecture": architecture,
        "total_events": total_events,
        "deadlines_met": deadlines_met,
        "deadlines_missed": deadlines_missed,
        "compliance_percentage": (
            deadlines_met / total_events
        ) * 100,
        "mean_latency_ms": sum(latencies) / total_events,
        "p95_latency_ms": calculate_percentile(latencies, 95),
        "p99_latency_ms": calculate_percentile(latencies, 99),
        "worst_case_latency_ms": max(latencies),
        "minimum_latency_ms": min(latencies)
    }


def run_all_architectures(
    number_of_events: int = 10000,
    sampling_period_ms: float = 50.0,
    congestion_level: float = 0.5,
    hard_decision_probability: float = 0.15,
    seed: int = 42,
    config: EdgeCloudConfig = None
) -> List[dict]:
    """Run and analyze Edge, Cloud, and Hybrid architectures."""

    if config is None:
        config = EdgeCloudConfig()

    # Edge and Cloud simulation
    edge_cloud_events = run_simulation(
        number_of_events=number_of_events,
        sampling_period_ms=sampling_period_ms,
        congestion_level=congestion_level,
        seed=seed,
        config=config
    )

    edge_events = [
        event for event in edge_cloud_events
        if event.execution_mode == "EDGE"
    ]

    cloud_events = [
        event for event in edge_cloud_events
        if event.execution_mode == "CLOUD"
    ]

    # Hybrid simulation
    hybrid_events = run_hybrid_simulation(
        number_of_events=number_of_events,
        sampling_period_ms=sampling_period_ms,
        congestion_level=congestion_level,
        hard_decision_probability=hard_decision_probability,
        seed=seed,
        config=config
    )

    results = [
        analyze_events(edge_events, "EDGE"),
        analyze_events(cloud_events, "CLOUD"),
        analyze_events(hybrid_events, "HYBRID")
    ]

    return results


def print_comparison_table(results: List[dict]):
    """Display the comparison of all architectures."""

    print("\n" + "=" * 115)
    print("EDGE, CLOUD AND HYBRID PERFORMANCE COMPARISON")
    print("=" * 115)

    header = (
        f"{'Architecture':<13}"
        f"{'Events':>9}"
        f"{'Met':>8}"
        f"{'Missed':>9}"
        f"{'Compliance':>12}"
        f"{'Mean':>10}"
        f"{'P95':>10}"
        f"{'P99':>10}"
        f"{'Worst':>10}"
    )

    print(header)
    print("-" * 115)

    for item in results:

        print(
            f"{item['architecture']:<13}"
            f"{item['total_events']:>9}"
            f"{item['deadlines_met']:>8}"
            f"{item['deadlines_missed']:>9}"
            f"{item['compliance_percentage']:>11.2f}%"
            f"{item['mean_latency_ms']:>10.2f}"
            f"{item['p95_latency_ms']:>10.2f}"
            f"{item['p99_latency_ms']:>10.2f}"
            f"{item['worst_case_latency_ms']:>10.2f}"
        )

    print("=" * 115)
    print("All latency values are in milliseconds.")


def save_comparison_csv(
    results: List[dict],
    output_path: str = "results/reports/architecture_comparison.csv"
):
    """Save architecture comparison metrics to CSV."""

    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    fieldnames = [
        "architecture",
        "total_events",
        "deadlines_met",
        "deadlines_missed",
        "compliance_percentage",
        "mean_latency_ms",
        "p95_latency_ms",
        "p99_latency_ms",
        "worst_case_latency_ms",
        "minimum_latency_ms"
    ]

    with open(output_path, "w", newline="", encoding="utf-8") as file:

        writer = csv.DictWriter(
            file,
            fieldnames=fieldnames
        )

        writer.writeheader()
        writer.writerows(results)

    print(f"\nComparison CSV saved: {output_path}")


if __name__ == "__main__":

    configuration = EdgeCloudConfig(
        deadline_ms=100.0
    )

    print("\nRunning performance analysis...")

    comparison_results = run_all_architectures(
        number_of_events=10000,
        sampling_period_ms=50.0,
        congestion_level=0.5,
        hard_decision_probability=0.15,
        seed=42,
        config=configuration
    )

    print_comparison_table(comparison_results)

    save_comparison_csv(comparison_results)
